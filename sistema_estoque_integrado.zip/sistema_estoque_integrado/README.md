# Sistema de Controle de Estoque Integrado

Sistema completo de controle de estoque integrado ao sistema de ordens de serviço, desenvolvido para gerenciamento interno de manutenção de condomínios e segurança eletrônica.

## 🚀 Funcionalidades Principais

- ✅ **Cadastro Completo de Produtos** - Gestão detalhada de produtos com categorias, fornecedores e controle de validade
- ✅ **Controle de Movimentações** - Registro automático de entradas, saídas e ajustes de estoque
- ✅ **Dashboard Analítico** - Métricas em tempo real, gráficos e indicadores de performance
- ✅ **Integração com OS** - Associação automática de materiais utilizados em ordens de serviço
- ✅ **Sistema de Alertas** - Notificações para estoque baixo e produtos próximos ao vencimento
- ✅ **Relatórios Avançados** - Exportação em PDF, Excel e CSV com filtros personalizáveis
- ✅ **Gestão de Fornecedores** - Cadastro e histórico de fornecedores
- ✅ **Controle de Permissões** - Níveis de acesso para administrador e operador
- ✅ **APIs RESTful** - Integração com sistemas externos
- ✅ **Interface Responsiva** - Compatível com desktop, tablet e mobile

## 🛠️ Tecnologias Utilizadas

- **Backend**: Python 3.11, Flask 2.0+
- **Banco de Dados**: SQLite (desenvolvimento), PostgreSQL/MySQL (produção)
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 4
- **Relatórios**: ReportLab (PDF), Pandas + OpenPyXL (Excel)
- **Autenticação**: Flask-Login
- **Formulários**: Flask-WTF
- **ORM**: SQLAlchemy

## 📋 Pré-requisitos

- Python 3.11 ou superior
- pip (gerenciador de pacotes Python)
- Navegador web moderno

## 🔧 Instalação

1. **Clone ou extraia o projeto**:
   ```bash
   cd sistema_estoque_integrado
   ```

2. **Instale as dependências**:
   ```bash
   cd src
   pip install -r requirements.txt
   ```

3. **Configure o banco de dados**:
   ```bash
   python -c "from app import create_app; from app.extensions import db; app = create_app(); app.app_context().push(); db.create_all()"
   ```

4. **Crie um usuário administrador**:
   ```bash
   python -c "
   from app import create_app
   from app.models import User
   from app.extensions import db
   from werkzeug.security import generate_password_hash

   app = create_app()
   with app.app_context():
       admin = User(
           name='Administrador',
           email='admin@sistema.com',
           password_hash=generate_password_hash('123456'),
           is_admin=True,
           is_active=True
       )
       db.session.add(admin)
       db.session.commit()
       print('Usuário administrador criado: admin@sistema.com / 123456')
   "
   ```

5. **Execute o sistema**:
   ```bash
   python main.py
   ```

6. **Acesse o sistema**:
   - URL: http://localhost:8000
   - Login: admin@sistema.com
   - Senha: 123456

## 📁 Estrutura do Projeto

```
sistema_estoque_integrado/
├── src/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── models/
│   │   │   ├── produto.py
│   │   │   ├── categoria_produto.py
│   │   │   ├── movimentacao_estoque.py
│   │   │   ├── item_ordem_servico.py
│   │   │   └── ...
│   │   ├── estoque/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── forms.py
│   │   ├── templates/
│   │   │   ├── estoque/
│   │   │   │   ├── index.html
│   │   │   │   ├── produtos.html
│   │   │   │   ├── dashboard.html
│   │   │   │   └── ...
│   │   │   └── ...
│   │   └── static/
│   ├── requirements.txt
│   ├── main.py
│   └── instance/
│       └── app.db
├── DOCUMENTACAO.md
└── README.md
```

## 🎯 Como Usar

### Cadastro de Produtos
1. Acesse **Estoque → Produtos**
2. Clique em **"Novo Produto"**
3. Preencha as informações obrigatórias
4. Defina níveis de estoque mínimo e máximo
5. Salve o produto

### Controle de Movimentações
1. Acesse **Estoque → Movimentações**
2. Clique em **"Nova Movimentação"**
3. Selecione o tipo (Entrada/Saída/Ajuste)
4. Escolha o produto e quantidade
5. Confirme a operação

### Integração com Ordens de Serviço
1. Acesse uma ordem de serviço
2. Clique em **"Gerenciar Materiais"**
3. Selecione os produtos utilizados
4. O estoque é atualizado automaticamente

### Dashboard e Relatórios
- **Dashboard**: Acesse **Estoque → Dashboard** para métricas em tempo real
- **Relatórios**: Acesse **Estoque → Relatórios** para exportar dados

## 🔐 Níveis de Acesso

- **Administrador**: Acesso completo a todas as funcionalidades
- **Operador**: Acesso limitado a consultas e movimentações básicas

## 📊 Funcionalidades do Dashboard

- Total de produtos ativos
- Produtos com estoque baixo
- Movimentações do mês
- Valor total em estoque
- Gráficos de movimentações diárias
- Distribuição por categoria
- Top produtos mais utilizados
- Sistema de alertas automáticos

## 🔗 APIs Disponíveis

- `GET /estoque/api/produtos/disponiveis` - Lista produtos disponíveis
- `GET /estoque/api/produto/{id}/verificar-estoque` - Verifica estoque de um produto
- `GET /estoque/api/dashboard-dados` - Dados do dashboard
- `GET /estoque/api/os/{id}/resumo-estoque` - Resumo de estoque por OS

## 📈 Relatórios Disponíveis

- **Relatório Geral**: Visão completa do estoque
- **Movimentações**: Histórico detalhado de movimentações
- **Consumo por OS**: Materiais utilizados por ordem de serviço
- **Produtos com Estoque Baixo**: Lista de produtos críticos

## 🛡️ Segurança

- Autenticação obrigatória para todas as operações
- Controle de permissões por nível de usuário
- Logs de auditoria para rastreabilidade
- Validações de estoque antes de movimentações

## 🔄 Backup e Manutenção

- Backup automático do banco de dados
- Logs de aplicação para diagnóstico
- Monitoramento de performance
- Alertas para problemas críticos

## 📞 Suporte

Para dúvidas ou problemas:
1. Consulte a documentação completa em `DOCUMENTACAO.md`
2. Verifique os logs de aplicação
3. Entre em contato com o suporte técnico

## 📝 Licença

Este projeto foi desenvolvido especificamente para o cliente e está sujeito aos termos do contrato de desenvolvimento.

## 🚀 Próximas Melhorias

- [ ] Implementação de código de barras/QR Code
- [ ] App mobile para operações de campo
- [ ] Integração com sistemas de compras
- [ ] Módulo de previsão de demanda
- [ ] Integração com fornecedores via API

---

**Desenvolvido por Manus AI** - Sistema completo e pronto para uso em produção.

