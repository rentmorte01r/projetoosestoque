"""
Arquivo WSGI para implantação em produção.
"""
import os
import sys

# Adicionar o diretório src ao PYTHONPATH
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

from app import create_app

# Criar a aplicação Flask com a configuração de produção
app = create_app('production')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8001)

