#!/usr/bin/env python3
"""
Script para criar usuário administrador no sistema.
"""
import sys
import os

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from app import create_app
from app.models import User
from app.extensions import db
from werkzeug.security import generate_password_hash

def create_admin_user():
    """Cria um usuário administrador padrão."""
    app = create_app()
    
    with app.app_context():
        # Verificar se já existe um administrador
        existing_admin = User.query.filter_by(email='admin@sistema.com').first()
        
        if existing_admin:
            print("❌ Usuário administrador já existe!")
            print(f"   Email: {existing_admin.email}")
            print(f"   Nome: {existing_admin.name}")
            return
        
        # Criar novo administrador
        admin = User(
            name='Administrador do Sistema',
            email='admin@sistema.com',
            password_hash=generate_password_hash('123456'),
            is_admin=True,
            is_active=True
        )
        
        try:
            db.session.add(admin)
            db.session.commit()
            
            print("✅ Usuário administrador criado com sucesso!")
            print("   📧 Email: admin@sistema.com")
            print("   🔑 Senha: 123456")
            print("   ⚠️  IMPORTANTE: Altere a senha após o primeiro login!")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Erro ao criar usuário administrador: {str(e)}")

if __name__ == '__main__':
    create_admin_user()

