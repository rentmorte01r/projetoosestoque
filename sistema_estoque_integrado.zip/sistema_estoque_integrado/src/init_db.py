from app import create_app
from app.extensions import db
from app.config import Config

def init_db():
    app = create_app(Config)
    with app.app_context():
        db.create_all()
        print("Banco de dados criado com sucesso!")

if __name__ == '__main__':
    init_db()