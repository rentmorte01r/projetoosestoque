from app import create_app
from app.extensions import db
from app.models import Condominio, User, Role, Permission, Administradora
from datetime import datetime

app = create_app()
app.app_context().push()

def create_initial_data():
    print("Criando dados iniciais...")

    # Criar administradora
    administradora = Administradora.query.filter_by(nome="Administradora Teste").first()
    if not administradora:
        administradora = Administradora(nome="Administradora Teste", cnpj="00.000.000/0001-00", email="contato@administradora.com", telefone="(11) 1234-5678", endereco="Rua da Administradora, 100")
        db.session.add(administradora)
        db.session.commit()
        print(f"Administradora '{administradora.nome}' criada.")
    else:
        print(f"Administradora '{administradora.nome}' já existe.")

    # Criar condomínio
    condominio = Condominio.query.filter_by(nome="Condominio Teste").first()
    if not condominio:
        condominio = Condominio(nome="Condominio Teste", endereco="Rua Teste, 123", cidade="Cidade Teste", estado="SP", cep="12345-678", telefone="(11) 98765-4321", email="contato@condominioteste.com", administradora_id=administradora.id)
        db.session.add(condominio)
        db.session.commit()
        print(f"Condomínio '{condominio.nome}' criado.")
    else:
        print(f"Condomínio '{condominio.nome}' já existe.")

    # Criar permissões
    admin_permission = Permission.query.filter_by(name='admin_access').first()
    if not admin_permission:
        admin_permission = Permission(name='admin_access', description='Acesso total ao painel administrativo')
        db.session.add(admin_permission)
        db.session.commit()
        print("Permissão 'admin_access' criada.")

    # Criar role de administrador
    admin_role = Role.query.filter_by(name='Administrador').first()
    if not admin_role:
        admin_role = Role(name='Administrador', description='Usuário com acesso total ao sistema')
        admin_role.permissions.append(admin_permission)
        db.session.add(admin_role)
        db.session.commit()
        print("Role 'Administrador' criada.")
    elif admin_permission not in admin_role.permissions:
        admin_role.permissions.append(admin_permission)
        db.session.commit()
        print("Permissão 'admin_access' adicionada à role 'Administrador'.")

    # Criar usuário administrador
    admin_user = User.query.filter_by(email="admin@sistema-os.com").first()
    if not admin_user:
        admin_user = User(name="Administrador", email="admin@sistema-os.com", is_admin=True, is_pending=False, is_active=True)
        admin_user.set_password("Admin123!")
        admin_user.roles.append(admin_role)
        db.session.add(admin_user)
        db.session.commit()
        print(f"Usuário administrador '{admin_user.email}' criado.")
    else:
        print(f"Usuário administrador '{admin_user.email}' já existe.")

    print("Dados iniciais criados com sucesso!")

if __name__ == '__main__':
    create_initial_data()


