"""
Módulos utilitários para a aplicação.
Este pacote contém funções e classes utilitárias reutilizáveis em toda a aplicação.
"""
