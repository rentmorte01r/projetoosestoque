"""
Sistema de notificações em tempo real.
Este módulo implementa notificações para eventos importantes do sistema.
"""
import json
from datetime import datetime, timedelta
from flask import current_app
from flask_login import current_user
from app.extensions import db
from app.models import User, OrdemServico, ActivityLog
from app.utils.email import send_notification_email


class NotificationManager:
    """Gerenciador de notificações do sistema."""
    
    @staticmethod
    def notify_ordem_created(ordem):
        """
        Notifica sobre criação de nova ordem de serviço.
        
        Args:
            ordem: Instância da OrdemServico
        """
        try:
            # Notificar administradores do condomínio
            users_to_notify = User.query.join(User.condominios).filter(
                User.condominios.any(id=ordem.condominio_id),
                User.is_active == True
            ).all()
            
            for user in users_to_notify:
                if user.email and user.receive_notifications:
                    send_notification_email(
                        to_email=user.email,
                        subject=f"Nova Ordem de Serviço #{ordem.id}",
                        template='emails/nova_ordem.html',
                        ordem=ordem,
                        user=user
                    )
            
            # Log da atividade
            ActivityLog.create(
                user_id=current_user.id if current_user.is_authenticated else None,
                action='ordem_created',
                description=f"Nova ordem de serviço criada: {ordem.titulo}",
                details={'ordem_id': ordem.id, 'condominio_id': ordem.condominio_id}
            )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar notificação de nova ordem: {str(e)}")
    
    @staticmethod
    def notify_ordem_status_changed(ordem, old_status, new_status):
        """
        Notifica sobre mudança de status de ordem de serviço.
        
        Args:
            ordem: Instância da OrdemServico
            old_status: Status anterior
            new_status: Novo status
        """
        try:
            # Notificar usuários interessados
            users_to_notify = []
            
            # Criador da ordem
            if ordem.criado_por:
                users_to_notify.append(ordem.criado_por)
            
            # Responsável pela ordem
            if ordem.responsavel:
                users_to_notify.append(ordem.responsavel)
            
            # Administradores do condomínio
            admin_users = User.query.join(User.condominios).filter(
                User.condominios.any(id=ordem.condominio_id),
                User.is_admin == True,
                User.is_active == True
            ).all()
            
            users_to_notify.extend(admin_users)
            
            # Remover duplicatas
            users_to_notify = list(set(users_to_notify))
            
            for user in users_to_notify:
                if user.email and user.receive_notifications:
                    send_notification_email(
                        to_email=user.email,
                        subject=f"Ordem #{ordem.id} - Status Atualizado",
                        template='emails/status_ordem.html',
                        ordem=ordem,
                        old_status=old_status,
                        new_status=new_status,
                        user=user
                    )
            
            # Log da atividade
            ActivityLog.create(
                user_id=current_user.id if current_user.is_authenticated else None,
                action='ordem_status_changed',
                description=f"Status da ordem {ordem.id} alterado de '{old_status}' para '{new_status}'",
                details={
                    'ordem_id': ordem.id,
                    'old_status': old_status,
                    'new_status': new_status
                }
            )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar notificação de mudança de status: {str(e)}")
    
    @staticmethod
    def notify_ordem_overdue():
        """Notifica sobre ordens em atraso."""
        try:
            # Buscar ordens em atraso
            today = datetime.now().date()
            overdue_orders = OrdemServico.query.filter(
                OrdemServico.data_previsao < today,
                OrdemServico.status.in_(['Aberta', 'Em Andamento'])
            ).all()
            
            if not overdue_orders:
                return
            
            # Agrupar por condomínio
            orders_by_condominio = {}
            for ordem in overdue_orders:
                if ordem.condominio_id not in orders_by_condominio:
                    orders_by_condominio[ordem.condominio_id] = []
                orders_by_condominio[ordem.condominio_id].append(ordem)
            
            # Notificar administradores de cada condomínio
            for condominio_id, orders in orders_by_condominio.items():
                admin_users = User.query.join(User.condominios).filter(
                    User.condominios.any(id=condominio_id),
                    User.is_admin == True,
                    User.is_active == True
                ).all()
                
                for user in admin_users:
                    if user.email and user.receive_notifications:
                        send_notification_email(
                            to_email=user.email,
                            subject=f"Ordens em Atraso - {orders[0].condominio.nome}",
                            template='emails/ordens_atraso.html',
                            orders=orders,
                            user=user
                        )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar notificações de atraso: {str(e)}")
    
    @staticmethod
    def notify_user_registered(user):
        """
        Notifica sobre novo usuário registrado.
        
        Args:
            user: Instância do User
        """
        try:
            # Notificar administradores do sistema
            admin_users = User.query.filter(
                User.is_admin == True,
                User.is_active == True
            ).all()
            
            for admin in admin_users:
                if admin.email:
                    send_notification_email(
                        to_email=admin.email,
                        subject="Novo Usuário Registrado",
                        template='emails/novo_usuario.html',
                        new_user=user,
                        admin=admin
                    )
            
            # Log da atividade
            ActivityLog.create(
                user_id=user.id,
                action='user_registered',
                description=f"Novo usuário registrado: {user.name} ({user.email})",
                details={'user_id': user.id}
            )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar notificação de novo usuário: {str(e)}")
    
    @staticmethod
    def notify_system_maintenance(message, scheduled_time=None):
        """
        Notifica sobre manutenção do sistema.
        
        Args:
            message: Mensagem de manutenção
            scheduled_time: Horário agendado para manutenção
        """
        try:
            # Notificar todos os usuários ativos
            active_users = User.query.filter(
                User.is_active == True,
                User.email.isnot(None)
            ).all()
            
            for user in active_users:
                if user.receive_notifications:
                    send_notification_email(
                        to_email=user.email,
                        subject="Manutenção do Sistema",
                        template='emails/manutencao.html',
                        message=message,
                        scheduled_time=scheduled_time,
                        user=user
                    )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar notificação de manutenção: {str(e)}")


class AlertManager:
    """Gerenciador de alertas do sistema."""
    
    @staticmethod
    def check_system_health():
        """Verifica a saúde do sistema e gera alertas se necessário."""
        alerts = []
        
        try:
            # Verificar espaço em disco
            import shutil
            total, used, free = shutil.disk_usage("/")
            free_percent = (free / total) * 100
            
            if free_percent < 10:
                alerts.append({
                    'type': 'critical',
                    'message': f"Espaço em disco baixo: {free_percent:.1f}% livre"
                })
            elif free_percent < 20:
                alerts.append({
                    'type': 'warning',
                    'message': f"Espaço em disco: {free_percent:.1f}% livre"
                })
            
            # Verificar ordens pendentes há muito tempo
            old_orders = OrdemServico.query.filter(
                OrdemServico.status == 'Aberta',
                OrdemServico.data_criacao < datetime.now() - timedelta(days=30)
            ).count()
            
            if old_orders > 0:
                alerts.append({
                    'type': 'warning',
                    'message': f"{old_orders} ordens abertas há mais de 30 dias"
                })
            
            # Verificar usuários pendentes de aprovação
            pending_users = User.query.filter(User.is_pending == True).count()
            
            if pending_users > 0:
                alerts.append({
                    'type': 'info',
                    'message': f"{pending_users} usuários pendentes de aprovação"
                })
            
            return alerts
            
        except Exception as e:
            current_app.logger.error(f"Erro ao verificar saúde do sistema: {str(e)}")
            return [{'type': 'error', 'message': 'Erro ao verificar sistema'}]
    
    @staticmethod
    def send_daily_summary():
        """Envia resumo diário para administradores."""
        try:
            # Calcular estatísticas do dia
            today = datetime.now().date()
            yesterday = today - timedelta(days=1)
            
            stats = {
                'new_orders': OrdemServico.query.filter(
                    OrdemServico.data_criacao >= yesterday,
                    OrdemServico.data_criacao < today
                ).count(),
                'completed_orders': OrdemServico.query.filter(
                    OrdemServico.status == 'Concluída',
                    OrdemServico.data_conclusao >= yesterday,
                    OrdemServico.data_conclusao < today
                ).count(),
                'pending_orders': OrdemServico.query.filter(
                    OrdemServico.status.in_(['Aberta', 'Em Andamento'])
                ).count(),
                'overdue_orders': OrdemServico.query.filter(
                    OrdemServico.data_previsao < today,
                    OrdemServico.status.in_(['Aberta', 'Em Andamento'])
                ).count()
            }
            
            # Enviar para administradores
            admin_users = User.query.filter(
                User.is_admin == True,
                User.is_active == True,
                User.receive_daily_summary == True
            ).all()
            
            for admin in admin_users:
                if admin.email:
                    send_notification_email(
                        to_email=admin.email,
                        subject=f"Resumo Diário - {today.strftime('%d/%m/%Y')}",
                        template='emails/resumo_diario.html',
                        stats=stats,
                        date=today,
                        admin=admin
                    )
            
        except Exception as e:
            current_app.logger.error(f"Erro ao enviar resumo diário: {str(e)}")


def setup_notification_system(app):
    """Configura o sistema de notificações."""
    app.logger.info("Sistema de notificações configurado")


def schedule_notifications():
    """Agenda notificações automáticas."""
    # Esta função seria chamada por um scheduler como Celery
    # Por enquanto, apenas registra que foi chamada
    current_app.logger.info("Verificando notificações agendadas")
    
    # Verificar ordens em atraso
    NotificationManager.notify_ordem_overdue()
    
    # Verificar saúde do sistema
    alerts = AlertManager.check_system_health()
    
    if alerts:
        current_app.logger.info(f"Alertas do sistema: {len(alerts)} alertas encontrados")
        
        # Enviar alertas críticos imediatamente
        critical_alerts = [a for a in alerts if a['type'] == 'critical']
        if critical_alerts:
            # Notificar administradores sobre alertas críticos
            admin_users = User.query.filter(
                User.is_admin == True,
                User.is_active == True
            ).all()
            
            for admin in admin_users:
                if admin.email:
                    send_notification_email(
                        to_email=admin.email,
                        subject="Alertas Críticos do Sistema",
                        template='emails/alertas_criticos.html',
                        alerts=critical_alerts,
                        admin=admin
                    )

