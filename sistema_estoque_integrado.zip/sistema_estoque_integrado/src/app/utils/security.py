"""
Utilitários de segurança para a aplicação.
Este módulo contém funções para melhorar a segurança da aplicação.
"""
import os
import secrets
import hashlib
from werkzeug.utils import secure_filename
from flask import current_app, request
from PIL import Image
import magic


def set_secure_headers(response):
    """
    Adiciona cabeçalhos de segurança às respostas HTTP.
    
    Args:
        response: Objeto de resposta Flask
        
    Returns:
        response: Resposta com cabeçalhos de segurança adicionados
    """
    # Proteção contra XSS
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    
    # Política de Segurança de Conteúdo (CSP)
    csp = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' "
        "https://cdn.jsdelivr.net https://cdnjs.cloudflare.com "
        "https://code.jquery.com; "
        "style-src 'self' 'unsafe-inline' "
        "https://cdn.jsdelivr.net https://cdnjs.cloudflare.com "
        "https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com "
        "https://cdnjs.cloudflare.com; "
        "img-src 'self' data: https:; "
        "connect-src 'self';"
    )
    response.headers['Content-Security-Policy'] = csp
    
    # Política de referrer
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    
    # Proteção contra MIME sniffing
    response.headers['X-Content-Type-Options'] = 'nosniff'
    
    return response


def generate_secure_filename(filename):
    """
    Gera um nome de arquivo seguro e único.
    
    Args:
        filename (str): Nome original do arquivo
        
    Returns:
        str: Nome de arquivo seguro e único
    """
    if not filename:
        return None
    
    # Obter extensão do arquivo
    file_ext = os.path.splitext(filename)[1].lower()
    
    # Gerar nome único
    unique_id = secrets.token_hex(16)
    
    # Criar nome seguro
    secure_name = f"{unique_id}{file_ext}"
    
    return secure_name


def validate_file_type(file, allowed_types):
    """
    Valida o tipo de arquivo baseado no conteúdo real.
    
    Args:
        file: Objeto de arquivo
        allowed_types (list): Lista de tipos MIME permitidos
        
    Returns:
        bool: True se o arquivo é válido, False caso contrário
    """
    if not file:
        return False
    
    try:
        # Verificar tipo MIME real do arquivo
        file_content = file.read(1024)  # Ler apenas os primeiros 1024 bytes
        file.seek(0)  # Voltar ao início do arquivo
        
        mime_type = magic.from_buffer(file_content, mime=True)
        
        return mime_type in allowed_types
    except Exception:
        return False


def resize_image(image_path, max_width=1920, max_height=1080, quality=85):
    """
    Redimensiona uma imagem mantendo a proporção.
    
    Args:
        image_path (str): Caminho para a imagem
        max_width (int): Largura máxima
        max_height (int): Altura máxima
        quality (int): Qualidade da compressão (1-100)
        
    Returns:
        bool: True se a operação foi bem-sucedida
    """
    try:
        with Image.open(image_path) as img:
            # Converter para RGB se necessário
            if img.mode in ('RGBA', 'LA', 'P'):
                img = img.convert('RGB')
            
            # Calcular novo tamanho mantendo proporção
            img.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
            
            # Salvar imagem otimizada
            img.save(image_path, 'JPEG', quality=quality, optimize=True)
            
        return True
    except Exception as e:
        current_app.logger.error(f"Erro ao redimensionar imagem {image_path}: {str(e)}")
        return False


def sanitize_input(text):
    """
    Sanitiza entrada de texto removendo caracteres perigosos.
    
    Args:
        text (str): Texto a ser sanitizado
        
    Returns:
        str: Texto sanitizado
    """
    if not text:
        return ""
    
    # Remover caracteres de controle
    sanitized = ''.join(char for char in text if ord(char) >= 32 or char in '\n\r\t')
    
    # Limitar tamanho
    sanitized = sanitized[:10000]  # Máximo 10k caracteres
    
    return sanitized.strip()


def generate_csrf_token():
    """
    Gera um token CSRF seguro.
    
    Returns:
        str: Token CSRF
    """
    return secrets.token_urlsafe(32)


def validate_password_strength(password):
    """
    Valida a força de uma senha.
    
    Args:
        password (str): Senha a ser validada
        
    Returns:
        tuple: (bool, list) - (é_válida, lista_de_erros)
    """
    errors = []
    
    if len(password) < 8:
        errors.append("A senha deve ter pelo menos 8 caracteres")
    
    if not any(c.isupper() for c in password):
        errors.append("A senha deve conter pelo menos uma letra maiúscula")
    
    if not any(c.islower() for c in password):
        errors.append("A senha deve conter pelo menos uma letra minúscula")
    
    if not any(c.isdigit() for c in password):
        errors.append("A senha deve conter pelo menos um número")
    
    if not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
        errors.append("A senha deve conter pelo menos um caractere especial")
    
    # Verificar senhas comuns
    common_passwords = [
        "123456", "password", "123456789", "12345678", "12345",
        "1234567", "1234567890", "qwerty", "abc123", "password123"
    ]
    
    if password.lower() in common_passwords:
        errors.append("Esta senha é muito comum e não é segura")
    
    return len(errors) == 0, errors


def hash_file(file_path):
    """
    Calcula o hash SHA-256 de um arquivo.
    
    Args:
        file_path (str): Caminho para o arquivo
        
    Returns:
        str: Hash SHA-256 do arquivo
    """
    sha256_hash = hashlib.sha256()
    
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    except Exception:
        return None


def get_client_ip():
    """
    Obtém o IP real do cliente considerando proxies.
    
    Returns:
        str: Endereço IP do cliente
    """
    # Verificar cabeçalhos de proxy
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    elif request.headers.get('X-Real-IP'):
        return request.headers.get('X-Real-IP')
    else:
        return request.remote_addr


def rate_limit_key():
    """
    Gera uma chave para rate limiting baseada no IP e usuário.
    
    Returns:
        str: Chave para rate limiting
    """
    from flask_login import current_user
    
    ip = get_client_ip()
    
    if current_user.is_authenticated:
        return f"user_{current_user.id}_{ip}"
    else:
        return f"ip_{ip}"


class SecurityConfig:
    """Configurações de segurança da aplicação."""
    
    # Tipos de arquivo permitidos
    ALLOWED_IMAGE_TYPES = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp'
    ]
    
    ALLOWED_DOCUMENT_TYPES = [
        'application/pdf', 'text/plain', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ]
    
    # Tamanhos máximos de arquivo (em bytes)
    MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB
    MAX_DOCUMENT_SIZE = 10 * 1024 * 1024  # 10MB
    
    # Configurações de sessão
    SESSION_TIMEOUT = 3600  # 1 hora
    
    # Rate limiting
    DEFAULT_RATE_LIMIT = "100 per hour"
    LOGIN_RATE_LIMIT = "5 per minute"
    API_RATE_LIMIT = "1000 per hour"



def save_file(file_data, upload_folder=None):
    """
    Salva um arquivo de forma segura.
    
    Args:
        file_data: Dados do arquivo (FileStorage object)
        upload_folder: Pasta de destino (opcional)
    
    Returns:
        str: Nome do arquivo salvo ou None se erro
    """
    if not file_data or not file_data.filename:
        return None
    
    try:
        import os
        import uuid
        from werkzeug.utils import secure_filename
        from flask import current_app
        
        # Gerar nome único para o arquivo
        filename = secure_filename(file_data.filename)
        name, ext = os.path.splitext(filename)
        unique_filename = f"{name}_{uuid.uuid4().hex[:8]}{ext}"
        
        # Determinar pasta de upload
        if not upload_folder:
            upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
        
        # Garantir que a pasta existe
        os.makedirs(upload_folder, exist_ok=True)
        
        # Salvar arquivo
        file_path = os.path.join(upload_folder, unique_filename)
        file_data.save(file_path)
        
        return unique_filename
        
    except Exception as e:
        current_app.logger.error(f"Erro ao salvar arquivo: {str(e)}")
        return None


def validate_file_type(filename, allowed_extensions=None):
    """
    Valida o tipo de arquivo baseado na extensão.
    
    Args:
        filename: Nome do arquivo
        allowed_extensions: Lista de extensões permitidas
    
    Returns:
        bool: True se válido, False caso contrário
    """
    if not filename:
        return False
    
    if not allowed_extensions:
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc', 'docx'}
    
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions


def get_file_size(file_data):
    """
    Obtém o tamanho de um arquivo.
    
    Args:
        file_data: Dados do arquivo (FileStorage object)
    
    Returns:
        int: Tamanho em bytes
    """
    if not file_data:
        return 0
    
    try:
        file_data.seek(0, 2)  # Ir para o final do arquivo
        size = file_data.tell()
        file_data.seek(0)  # Voltar para o início
        return size
    except:
        return 0

