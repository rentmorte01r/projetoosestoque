"""
Utilitários de performance para otimização da aplicação.
Este módulo contém funções para melhorar a performance do sistema.
"""
import time
import functools
from flask import current_app, g, request
from flask_login import current_user
from sqlalchemy import event
from sqlalchemy.engine import Engine
import sqlite3


def timing_decorator(func):
    """
    Decorator para medir tempo de execução de funções.
    
    Args:
        func: Função a ser decorada
        
    Returns:
        function: Função decorada com medição de tempo
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        
        execution_time = end_time - start_time
        
        # Log apenas se demorar mais que 1 segundo
        if execution_time > 1.0:
            current_app.logger.warning(
                f"Função {func.__name__} demorou {execution_time:.2f}s para executar"
            )
        
        return result
    return wrapper


def cache_key_generator(*args, **kwargs):
    """
    Gera chave de cache baseada nos argumentos da função.
    
    Returns:
        str: Chave de cache única
    """
    from flask_login import current_user
    
    # Incluir ID do usuário na chave se autenticado
    user_id = current_user.id if current_user.is_authenticated else 'anonymous'
    
    # Criar chave baseada nos argumentos
    key_parts = [str(user_id)]
    key_parts.extend([str(arg) for arg in args])
    key_parts.extend([f"{k}:{v}" for k, v in sorted(kwargs.items())])
    
    return "_".join(key_parts)


def optimize_query(query):
    """
    Otimiza uma query SQLAlchemy adicionando eager loading quando apropriado.
    
    Args:
        query: Query SQLAlchemy
        
    Returns:
        query: Query otimizada
    """
    # Esta função pode ser expandida para adicionar otimizações específicas
    # baseadas no tipo de query e relacionamentos
    return query


class DatabaseOptimizer:
    """Classe para otimizações de banco de dados."""
    
    @staticmethod
    def setup_sqlite_optimizations():
        """Configura otimizações específicas para SQLite."""
        
        @event.listens_for(Engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            if isinstance(dbapi_connection, sqlite3.Connection):
                cursor = dbapi_connection.cursor()
                
                # Otimizações de performance para SQLite
                cursor.execute("PRAGMA journal_mode=WAL")  # Write-Ahead Logging
                cursor.execute("PRAGMA synchronous=NORMAL")  # Balanceamento entre segurança e performance
                cursor.execute("PRAGMA cache_size=10000")  # Cache maior
                cursor.execute("PRAGMA temp_store=MEMORY")  # Armazenar temporários em memória
                cursor.execute("PRAGMA mmap_size=268435456")  # 256MB de memory mapping
                
                cursor.close()
    
    @staticmethod
    def analyze_slow_queries():
        """Analisa queries lentas e registra no log."""
        
        @event.listens_for(Engine, "before_cursor_execute")
        def receive_before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            context._query_start_time = time.time()
        
        @event.listens_for(Engine, "after_cursor_execute")
        def receive_after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            total = time.time() - context._query_start_time
            
            # Log queries que demoram mais que 500ms
            if total > 0.5:
                current_app.logger.warning(
                    f"Query lenta detectada ({total:.2f}s): {statement[:100]}..."
                )


class MemoryOptimizer:
    """Classe para otimizações de memória."""
    
    @staticmethod
    def cleanup_session():
        """Limpa dados desnecessários da sessão."""
        # Remove dados temporários que podem estar ocupando memória
        if hasattr(g, 'temp_data'):
            delattr(g, 'temp_data')
    
    @staticmethod
    def optimize_image_processing():
        """Otimiza processamento de imagens para usar menos memória."""
        from PIL import Image
        
        # Configurar PIL para usar menos memória
        Image.MAX_IMAGE_PIXELS = 50000000  # Limitar tamanho máximo de imagem
        
        return True


class CacheManager:
    """Gerenciador de cache para otimização de performance."""
    
    def __init__(self, cache):
        self.cache = cache
    
    def get_or_set(self, key, func, timeout=300):
        """
        Obtém valor do cache ou executa função e armazena resultado.
        
        Args:
            key (str): Chave do cache
            func (callable): Função a ser executada se não houver cache
            timeout (int): Tempo de expiração em segundos
            
        Returns:
            Resultado da função ou valor do cache
        """
        result = self.cache.get(key)
        
        if result is None:
            result = func()
            self.cache.set(key, result, timeout=timeout)
        
        return result
    
    def invalidate_pattern(self, pattern):
        """
        Invalida todas as chaves de cache que correspondem ao padrão.
        
        Args:
            pattern (str): Padrão para invalidação
        """
        # Implementação específica dependendo do backend de cache
        # Para SimpleCache, precisaríamos iterar sobre as chaves
        pass
    
    def warm_up_cache(self):
        """Pré-aquece o cache com dados frequentemente acessados."""
        from app.models import User, Condominio, OrdemServico
        
        try:
            # Cache de estatísticas básicas
            total_users = User.query.count()
            self.cache.set('stats_total_users', total_users, timeout=3600)
            
            total_condominios = Condominio.query.count()
            self.cache.set('stats_total_condominios', total_condominios, timeout=3600)
            
            total_ordens = OrdemServico.query.count()
            self.cache.set('stats_total_ordens', total_ordens, timeout=1800)
            
            current_app.logger.info("Cache pré-aquecido com sucesso")
            
        except Exception as e:
            current_app.logger.error(f"Erro ao pré-aquecer cache: {str(e)}")


class RequestOptimizer:
    """Otimizador de requisições HTTP."""
    
    @staticmethod
    def setup_request_optimization(app):
        """Configura otimizações de requisição."""
        
        @app.before_request
        def optimize_request():
            # Marcar início da requisição
            g.start_time = time.time()
            
            # Configurar compressão para respostas grandes
            if request.content_length and request.content_length > 1024:
                g.should_compress = True
        
        @app.after_request
        def log_request_time(response):
            if hasattr(g, 'start_time'):
                request_time = time.time() - g.start_time
                
                # Log requisições lentas
                if request_time > 2.0:
                    current_app.logger.warning(
                        f"Requisição lenta: {request.method} {request.path} "
                        f"({request_time:.2f}s)"
                    )
                
                # Adicionar cabeçalho de tempo de resposta
                response.headers['X-Response-Time'] = f"{request_time:.3f}s"
            
            return response


def setup_performance_monitoring(app):
    """Configura monitoramento de performance da aplicação."""
    
    # Configurar otimizações de banco de dados
    DatabaseOptimizer.setup_sqlite_optimizations()
    DatabaseOptimizer.analyze_slow_queries()
    
    # Configurar otimizações de requisição
    RequestOptimizer.setup_request_optimization(app)
    
    # Configurar otimizações de memória
    MemoryOptimizer.optimize_image_processing()
    
    app.logger.info("Monitoramento de performance configurado")


def performance_report():
    """
    Gera relatório de performance da aplicação.
    
    Returns:
        dict: Relatório de performance
    """
    import psutil
    import os
    
    try:
        process = psutil.Process(os.getpid())
        
        report = {
            'memory_usage': {
                'rss': process.memory_info().rss / 1024 / 1024,  # MB
                'vms': process.memory_info().vms / 1024 / 1024,  # MB
                'percent': process.memory_percent()
            },
            'cpu_usage': process.cpu_percent(),
            'open_files': len(process.open_files()),
            'connections': len(process.connections()),
            'threads': process.num_threads()
        }
        
        return report
        
    except Exception as e:
        current_app.logger.error(f"Erro ao gerar relatório de performance: {str(e)}")
        return {}


# Decorators para cache automático
def cached_result(timeout=300, key_prefix=''):
    """
    Decorator para cache automático de resultados de função.
    
    Args:
        timeout (int): Tempo de expiração em segundos
        key_prefix (str): Prefixo para a chave de cache
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            from app.extensions import cache
            
            # Gerar chave de cache
            cache_key = f"{key_prefix}_{func.__name__}_{cache_key_generator(*args, **kwargs)}"
            
            # Tentar obter do cache
            result = cache.get(cache_key)
            
            if result is None:
                # Executar função e armazenar no cache
                result = func(*args, **kwargs)
                cache.set(cache_key, result, timeout=timeout)
            
            return result
        return wrapper
    return decorator

