"""
Sistema de backup automático para o banco de dados e arquivos.
Este módulo implementa backup automático e restauração de dados.
"""
import os
import shutil
import sqlite3
import zipfile
import json
from datetime import datetime, timedelta
from flask import current_app
from app.extensions import db


class BackupManager:
    """Gerenciador de backup do sistema."""
    
    def __init__(self, app=None):
        if app:
            self.backup_dir = os.path.join(app.instance_path, 'backups')
        else:
            self.backup_dir = os.path.join(os.getcwd(), 'backups')
        self.ensure_backup_directory()
    
    def ensure_backup_directory(self):
        """Garante que o diretório de backup existe."""
        os.makedirs(self.backup_dir, exist_ok=True)
    
    def create_database_backup(self):
        """
        Cria backup do banco de dados.
        
        Returns:
            str: Caminho do arquivo de backup criado
        """
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_filename = f"database_backup_{timestamp}.db"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            # Para SQLite, simplesmente copiar o arquivo
            db_path = current_app.config.get('DATABASE_URL', '').replace('sqlite:///', '')
            if db_path and os.path.exists(db_path):
                shutil.copy2(db_path, backup_path)
                
                # Criar arquivo de metadados
                metadata = {
                    'timestamp': timestamp,
                    'database_size': os.path.getsize(backup_path),
                    'app_version': current_app.config.get('VERSION', '1.0.0'),
                    'backup_type': 'database'
                }
                
                metadata_path = backup_path.replace('.db', '_metadata.json')
                with open(metadata_path, 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                current_app.logger.info(f"Backup do banco de dados criado: {backup_filename}")
                return backup_path
            else:
                raise Exception("Arquivo de banco de dados não encontrado")
                
        except Exception as e:
            current_app.logger.error(f"Erro ao criar backup do banco: {str(e)}")
            raise
    
    def create_files_backup(self):
        """
        Cria backup dos arquivos de upload.
        
        Returns:
            str: Caminho do arquivo de backup criado
        """
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_filename = f"files_backup_{timestamp}.zip"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            upload_folder = current_app.config.get('UPLOAD_FOLDER')
            
            if upload_folder and os.path.exists(upload_folder):
                with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for root, dirs, files in os.walk(upload_folder):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, upload_folder)
                            zipf.write(file_path, arcname)
                
                # Criar arquivo de metadados
                metadata = {
                    'timestamp': timestamp,
                    'files_count': len(zipf.namelist()) if 'zipf' in locals() else 0,
                    'backup_size': os.path.getsize(backup_path),
                    'backup_type': 'files'
                }
                
                metadata_path = backup_path.replace('.zip', '_metadata.json')
                with open(metadata_path, 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                current_app.logger.info(f"Backup dos arquivos criado: {backup_filename}")
                return backup_path
            else:
                current_app.logger.warning("Pasta de uploads não encontrada para backup")
                return None
                
        except Exception as e:
            current_app.logger.error(f"Erro ao criar backup dos arquivos: {str(e)}")
            raise
    
    def create_full_backup(self):
        """
        Cria backup completo (banco + arquivos).
        
        Returns:
            str: Caminho do arquivo de backup completo
        """
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_filename = f"full_backup_{timestamp}.zip"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            # Criar backups individuais
            db_backup = self.create_database_backup()
            files_backup = self.create_files_backup()
            
            # Combinar em um arquivo ZIP
            with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                if db_backup:
                    zipf.write(db_backup, os.path.basename(db_backup))
                    # Adicionar metadados do banco
                    db_metadata = db_backup.replace('.db', '_metadata.json')
                    if os.path.exists(db_metadata):
                        zipf.write(db_metadata, os.path.basename(db_metadata))
                
                if files_backup:
                    zipf.write(files_backup, os.path.basename(files_backup))
                    # Adicionar metadados dos arquivos
                    files_metadata = files_backup.replace('.zip', '_metadata.json')
                    if os.path.exists(files_metadata):
                        zipf.write(files_metadata, os.path.basename(files_metadata))
            
            # Criar metadados do backup completo
            metadata = {
                'timestamp': timestamp,
                'backup_type': 'full',
                'includes_database': db_backup is not None,
                'includes_files': files_backup is not None,
                'total_size': os.path.getsize(backup_path)
            }
            
            metadata_path = backup_path.replace('.zip', '_metadata.json')
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Limpar backups individuais temporários
            if db_backup and os.path.exists(db_backup):
                os.remove(db_backup)
                db_metadata = db_backup.replace('.db', '_metadata.json')
                if os.path.exists(db_metadata):
                    os.remove(db_metadata)
            
            if files_backup and os.path.exists(files_backup):
                os.remove(files_backup)
                files_metadata = files_backup.replace('.zip', '_metadata.json')
                if os.path.exists(files_metadata):
                    os.remove(files_metadata)
            
            current_app.logger.info(f"Backup completo criado: {backup_filename}")
            return backup_path
            
        except Exception as e:
            current_app.logger.error(f"Erro ao criar backup completo: {str(e)}")
            raise
    
    def list_backups(self):
        """
        Lista todos os backups disponíveis.
        
        Returns:
            list: Lista de backups com metadados
        """
        backups = []
        
        try:
            for filename in os.listdir(self.backup_dir):
                if filename.endswith(('.db', '.zip')) and 'backup' in filename:
                    backup_path = os.path.join(self.backup_dir, filename)
                    metadata_path = backup_path.replace('.db', '_metadata.json').replace('.zip', '_metadata.json')
                    
                    backup_info = {
                        'filename': filename,
                        'path': backup_path,
                        'size': os.path.getsize(backup_path),
                        'created': datetime.fromtimestamp(os.path.getctime(backup_path))
                    }
                    
                    # Carregar metadados se existirem
                    if os.path.exists(metadata_path):
                        try:
                            with open(metadata_path, 'r') as f:
                                metadata = json.load(f)
                                backup_info.update(metadata)
                        except Exception:
                            pass
                    
                    backups.append(backup_info)
            
            # Ordenar por data de criação (mais recente primeiro)
            backups.sort(key=lambda x: x['created'], reverse=True)
            
        except Exception as e:
            current_app.logger.error(f"Erro ao listar backups: {str(e)}")
        
        return backups
    
    def cleanup_old_backups(self, keep_days=30):
        """
        Remove backups antigos.
        
        Args:
            keep_days (int): Número de dias para manter backups
        """
        try:
            cutoff_date = datetime.now() - timedelta(days=keep_days)
            removed_count = 0
            
            for filename in os.listdir(self.backup_dir):
                if 'backup' in filename:
                    file_path = os.path.join(self.backup_dir, filename)
                    file_date = datetime.fromtimestamp(os.path.getctime(file_path))
                    
                    if file_date < cutoff_date:
                        os.remove(file_path)
                        removed_count += 1
                        
                        # Remover arquivo de metadados associado
                        if filename.endswith(('.db', '.zip')):
                            metadata_path = file_path.replace('.db', '_metadata.json').replace('.zip', '_metadata.json')
                            if os.path.exists(metadata_path):
                                os.remove(metadata_path)
            
            if removed_count > 0:
                current_app.logger.info(f"Removidos {removed_count} backups antigos")
                
        except Exception as e:
            current_app.logger.error(f"Erro ao limpar backups antigos: {str(e)}")
    
    def restore_database(self, backup_path):
        """
        Restaura banco de dados a partir de backup.
        
        Args:
            backup_path (str): Caminho do arquivo de backup
            
        Returns:
            bool: True se restauração foi bem-sucedida
        """
        try:
            if not os.path.exists(backup_path):
                raise Exception("Arquivo de backup não encontrado")
            
            db_path = current_app.config.get('DATABASE_URL', '').replace('sqlite:///', '')
            
            if not db_path:
                raise Exception("Caminho do banco de dados não configurado")
            
            # Criar backup do banco atual antes de restaurar
            current_backup = f"{db_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            if os.path.exists(db_path):
                shutil.copy2(db_path, current_backup)
            
            # Restaurar banco
            shutil.copy2(backup_path, db_path)
            
            current_app.logger.info(f"Banco de dados restaurado de: {backup_path}")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Erro ao restaurar banco de dados: {str(e)}")
            return False


def schedule_automatic_backup():
    """Agenda backup automático."""
    try:
        backup_manager = BackupManager()
        
        # Criar backup completo
        backup_path = backup_manager.create_full_backup()
        
        # Limpar backups antigos
        backup_manager.cleanup_old_backups(keep_days=30)
        
        current_app.logger.info("Backup automático executado com sucesso")
        return backup_path
        
    except Exception as e:
        current_app.logger.error(f"Erro no backup automático: {str(e)}")
        return None


def setup_backup_system(app):
    """Configura o sistema de backup."""
    app.logger.info("Sistema de backup configurado")
    
    # Criar backup inicial se não existir nenhum
    backup_manager = BackupManager(app)
    backups = backup_manager.list_backups()
    


