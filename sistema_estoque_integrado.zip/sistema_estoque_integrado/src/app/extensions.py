"""
Extensões Flask utilizadas na aplicação.
Este módulo inicializa e configura todas as extensões Flask utilizadas no sistema.
"""
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_mail import Mail
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_caching import Cache
from flask_compress import Compress
from flask_cors import CORS
from flask_bcrypt import Bcrypt

# Inicialização das extensões
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
csrf = CSRFProtect()
mail = Mail()
limiter = Limiter(key_func=get_remote_address)
cache = Cache()
compress = Compress()
cors = CORS()
bcrypt = Bcrypt()

def init_extensions(app):
    """
    Inicializa todas as extensões Flask com a aplicação.
    
    Args:
        app: Instância da aplicação Flask
    """
    # Configuração do SQLAlchemy
    db.init_app(app)
    migrate.init_app(app, db)
    
    # Configuração do Login Manager
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'info'
    
    # Configurar user_loader
    @login_manager.user_loader
    def load_user(user_id):
        from app.models.user import User
        return User.query.get(int(user_id))
    
    # Proteção CSRF
    csrf.init_app(app)
    
    # Configuração do Flask-Mail
    mail.init_app(app)
    
    # Configuração do Rate Limiter
    limiter.init_app(app)
    
    # Configuração do Cache
    cache_config = {
        'CACHE_TYPE': 'SimpleCache',
        'CACHE_DEFAULT_TIMEOUT': 300
    }
    app.config.from_mapping(cache_config)
    cache.init_app(app)
    
    # Compressão de respostas
    compress.init_app(app)
    
    # Configuração do CORS
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    
    # Configuração do Bcrypt
    bcrypt.init_app(app)
    
    # Configuração de cabeçalhos de segurança
    @app.after_request
    def add_security_headers(response):
        try:
            from .utils.security import set_secure_headers
            return set_secure_headers(response)
        except ImportError:
            # Se o módulo de segurança não existir, apenas retorna a resposta
            return response
    
    # Configuração de logs de atividade
    @app.before_request
    def log_request_info():
        import logging
        from flask import request
        from flask_login import current_user
        
        logger = logging.getLogger('request_logger')
        
        # Registra informações básicas da requisição
        try:
            user_id = current_user.id if current_user.is_authenticated else 'Anônimo'
        except:
            user_id = 'Anônimo'
        
        logger.info(f"Requisição: {request.method} {request.path} - Usuário: {user_id}")
    
    # Configurar sistemas adicionais
    try:
        from .utils.performance import setup_performance_monitoring
        setup_performance_monitoring(app)
    except ImportError:
        pass
    
    try:
        from .utils.notifications import setup_notification_system
        setup_notification_system(app)
    except ImportError:
        pass
    
    try:
        from .utils.backup import setup_backup_system
        setup_backup_system(app)
    except ImportError:
        pass
    
    # Configuração de tratamento de erros
    register_error_handlers(app)
    
    # Configurar contexto global para templates
    @app.context_processor
    def inject_now():
        from datetime import datetime
        return {'now': datetime.now()}

def register_error_handlers(app):
    """
    Registra handlers para erros HTTP comuns.
    
    Args:
        app: Instância da aplicação Flask
    """
    @app.errorhandler(400)
    def bad_request_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=400, 
                              title='Requisição Inválida',
                              message='A requisição enviada contém erros ou está mal formatada.'), 400
    
    @app.errorhandler(401)
    def unauthorized_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=401, 
                              title='Não Autorizado',
                              message='Você precisa fazer login para acessar esta página.'), 401
    
    @app.errorhandler(403)
    def forbidden_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=403, 
                              title='Acesso Negado',
                              message='Você não tem permissão para acessar esta página.'), 403
    
    @app.errorhandler(404)
    def not_found_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=404, 
                              title='Página Não Encontrada',
                              message='A página que você está procurando não existe ou foi movida.'), 404
    
    @app.errorhandler(429)
    def too_many_requests_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=429, 
                              title='Muitas Requisições',
                              message='Você enviou muitas requisições. Por favor, aguarde um momento e tente novamente.'), 429
    
    @app.errorhandler(500)
    def internal_server_error(error):
        from flask import render_template
        return render_template('errors/error.html', code=500, 
                              title='Erro Interno do Servidor',
                              message='Ocorreu um erro interno no servidor. Nossa equipe foi notificada.'), 500



def register_error_handlers(app):
    """Registra manipuladores de erro personalizados."""
    
    @app.errorhandler(404)
    def not_found_error(error):
        from flask import render_template, request
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        from flask import render_template
        db.session.rollback()
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(403)
    def forbidden_error(error):
        from flask import render_template
        return render_template('errors/403.html'), 403
    
    @app.errorhandler(429)
    def ratelimit_handler(e):
        from flask import render_template
        return render_template('errors/429.html'), 429

