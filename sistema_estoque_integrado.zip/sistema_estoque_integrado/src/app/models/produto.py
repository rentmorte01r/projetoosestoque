"""
Módulo para o modelo Produto.
"""
from datetime import datetime
from app.extensions import db

class Produto(db.Model):
    """Modelo de produto para controle de estoque."""
    __tablename__ = 'produtos'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(255), nullable=False, index=True)
    codigo = db.Column(db.String(50), unique=True, nullable=False, index=True)
    descricao = db.Column(db.Text)
    unidade_medida = db.Column(db.String(20), nullable=False, default='UN')
    quantidade_atual = db.Column(db.Integer, nullable=False, default=0)
    preco_custo = db.Column(db.Numeric(10, 2))
    local_armazenamento = db.Column(db.String(100))
    categoria_id = db.Column(db.Integer, db.ForeignKey('categorias_produto.id'))
    fornecedor_id = db.Column(db.Integer, db.ForeignKey('fornecedores.id'))
    estoque_minimo = db.Column(db.Integer, default=0)
    estoque_maximo = db.Column(db.Integer, default=0)
    data_vencimento = db.Column(db.DateTime)
    ativo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    fornecedor = db.relationship('Fornecedor', backref='produtos_fornecidos')
    movimentacoes = db.relationship('MovimentacaoEstoque', backref='produto', lazy='dynamic')
    
    def __repr__(self):
        return f'<Produto {self.codigo} - {self.nome}>'
    
    @property
    def status_estoque(self):
        """Retorna o status do estoque baseado nos limites mínimo e máximo."""
        if self.estoque_minimo > 0 and self.quantidade_atual <= self.estoque_minimo:
            return 'BAIXO'
        elif self.estoque_maximo > 0 and self.quantidade_atual >= self.estoque_maximo:
            return 'ALTO'
        else:
            return 'NORMAL'
    
    @property
    def dias_para_vencimento(self):
        """Retorna o número de dias para o vencimento, se aplicável."""
        if self.data_vencimento:
            delta = self.data_vencimento - datetime.utcnow()
            return delta.days
        return None
    
    @property
    def vencimento_proximo(self):
        """Verifica se o produto está próximo do vencimento (30 dias)."""
        dias = self.dias_para_vencimento
        return dias is not None and 0 <= dias <= 30
    
    def atualizar_quantidade(self, quantidade_delta, tipo_movimentacao='AJUSTE', usuario_id=None, ordem_servico_id=None, observacoes=None):
        """
        Atualiza a quantidade do produto e registra a movimentação.
        
        Args:
            quantidade_delta: Quantidade a ser adicionada (positiva) ou removida (negativa)
            tipo_movimentacao: Tipo da movimentação (ENTRADA, SAIDA, AJUSTE)
            usuario_id: ID do usuário que realizou a movimentação
            ordem_servico_id: ID da ordem de serviço (se aplicável)
            observacoes: Observações sobre a movimentação
        """
        from .movimentacao_estoque import MovimentacaoEstoque
        
        # Atualiza a quantidade atual
        self.quantidade_atual += quantidade_delta
        
        # Garante que a quantidade não seja negativa
        if self.quantidade_atual < 0:
            self.quantidade_atual = 0
        
        # Registra a movimentação
        movimentacao = MovimentacaoEstoque(
            produto_id=self.id,
            tipo_movimentacao=tipo_movimentacao,
            quantidade=abs(quantidade_delta),
            usuario_id=usuario_id,
            ordem_servico_id=ordem_servico_id,
            observacoes=observacoes
        )
        
        db.session.add(movimentacao)
        db.session.commit()
    
    def to_dict(self):
        """Converte o objeto para dicionário para serialização JSON."""
        return {
            'id': self.id,
            'nome': self.nome,
            'codigo': self.codigo,
            'descricao': self.descricao,
            'unidade_medida': self.unidade_medida,
            'quantidade_atual': self.quantidade_atual,
            'preco_custo': float(self.preco_custo) if self.preco_custo else None,
            'local_armazenamento': self.local_armazenamento,
            'categoria_id': self.categoria_id,
            'categoria_nome': self.categoria.nome if self.categoria else None,
            'fornecedor_id': self.fornecedor_id,
            'fornecedor_nome': self.fornecedor.nome if self.fornecedor else None,
            'estoque_minimo': self.estoque_minimo,
            'estoque_maximo': self.estoque_maximo,
            'data_vencimento': self.data_vencimento.isoformat() if self.data_vencimento else None,
            'status_estoque': self.status_estoque,
            'vencimento_proximo': self.vencimento_proximo,
            'dias_para_vencimento': self.dias_para_vencimento,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

