"""
Módulo para o modelo CategoriaProduto.
"""
from datetime import datetime
from app.extensions import db

class CategoriaProduto(db.Model):
    """Modelo de categoria de produtos para estoque."""
    __tablename__ = 'categorias_produto'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True, index=True)
    descricao = db.Column(db.Text)
    ativo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    produtos = db.relationship('Produto', backref='categoria', lazy='dynamic')
    
    def __repr__(self):
        return f'<CategoriaProduto {self.nome}>'
    
    def to_dict(self):
        """Converte o objeto para dicionário para serialização JSON."""
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

