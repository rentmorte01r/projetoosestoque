"""
Módulo para o modelo Fornecedor.
"""
from datetime import datetime
from app.extensions import db

class Fornecedor(db.Model):
    """Modelo de fornecedor de serviços."""
    __tablename__ = 'fornecedores'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(255), nullable=False, index=True)
    cnpj_cpf = db.Column(db.String(18), unique=True)
    email = db.Column(db.String(120))
    telefone = db.Column(db.String(20))
    endereco = db.Column(db.String(255))
    tipo_servico = db.Column(db.String(100))
    tipo_fornecedor = db.Column(db.String(20), default='Serviço')  # 'Serviço', 'Produto', 'Ambos'
    observacoes = db.Column(db.Text)
    ativo = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Fornecedor {self.nome}>'

    
    def to_dict(self):
        """Converte o objeto para dicionário para serialização JSON."""
        return {
            'id': self.id,
            'nome': self.nome,
            'cnpj_cpf': self.cnpj_cpf,
            'email': self.email,
            'telefone': self.telefone,
            'endereco': self.endereco,
            'tipo_servico': self.tipo_servico,
            'tipo_fornecedor': self.tipo_fornecedor,
            'observacoes': self.observacoes,
            'ativo': self.ativo,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

