"""
Módulo de modelos para usuários e autenticação.
Este módulo define os modelos relacionados a usuários, permissões e autenticação.
"""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, bcrypt

class User(db.Model, UserMixin):
    """Modelo de usuário do sistema."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_pending = db.Column(db.Boolean, default=True)
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    # Corrigido: Usando back_populates em vez de backref para evitar conflito
    condominios = db.relationship('Condominio', secondary='user_condominio', back_populates='users')
    roles = db.relationship('Role', secondary='user_role', back_populates='users') # Adicionado back_populates para roles
    
    def __init__(self, **kwargs):
        """
        Inicializa um novo usuário.
        Se a senha for fornecida em texto plano, converte para hash.
        """
        if 'password' in kwargs and kwargs['password']:
            # A senha já é tratada pelo set_password ou no __init__ do modelo base?
            # Vamos garantir que o hash seja feito aqui se a senha for passada diretamente.
            # No entanto, o script create_admin usa set_password, então isso pode não ser necessário.
            # Removendo a lógica de hash daqui para confiar no set_password.
            pass
        super(User, self).__init__(**kwargs)
    
    def set_password(self, password):
        """Define a senha do usuário, convertendo para hash."""
        self.password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    def check_password(self, password):
        """Verifica se a senha fornecida corresponde à senha do usuário."""
        # Garante que self.password não seja None antes de verificar
        if self.password:
            return bcrypt.check_password_hash(self.password, password)
        return False
    
    def has_condominio_access(self, condominio_id):
        """Verifica se o usuário tem acesso ao condomínio especificado."""
        return any(c.id == condominio_id for c in self.condominios)
    
    def update_last_login(self):
        """Atualiza a data do último login do usuário."""
        self.last_login = datetime.utcnow()
        db.session.commit()
    
    def has_permission(self, permission_name):
        """Verifica se o usuário tem a permissão especificada."""
        # Administradores têm todas as permissões
        if self.is_admin:
            return True
        
        # Verifica se algum dos papéis do usuário tem a permissão
        for role in self.roles:
            for permission in role.permissions:
                if permission.name == permission_name:
                    return True
        return False
    
    def __repr__(self):
        return f'<User {self.name}>'


class UserCondominio(db.Model):
    """Associação entre usuários e condomínios."""
    __tablename__ = 'user_condominio'
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    condominio_id = db.Column(db.Integer, db.ForeignKey('condominios.id'), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

