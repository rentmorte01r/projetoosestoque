"""
Módulo para o modelo PasswordReset.
"""
from datetime import datetime
from app.extensions import db

class PasswordReset(db.Model):
    """Modelo para tokens de redefinição de senha."""
    __tablename__ = 'password_resets'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    token = db.Column(db.String(100), nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    
    # Relacionamento (opcional)
    # user = db.relationship('User', backref='password_resets')

    def is_expired(self):
        """Verifica se o token expirou."""
        return datetime.utcnow() > self.expires_at
    
    def __repr__(self):
        return f'<PasswordReset for user_id={self.user_id}>'
