"""
Módulo de modelos para Roles e permissões.
"""
from datetime import datetime
from app.extensions import db

class Role(db.Model):
    """Modelo de papel/função de usuário com permissões associadas."""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    description = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento com usuários (muitos para muitos)
    users = db.relationship('User', secondary='user_role', back_populates='roles')
    
    # Relacionamento com permissões (muitos para muitos)
    permissions = db.relationship('Permission', secondary='role_permission', back_populates='roles')

    def has_permission(self, permission):
        """Verifica se o papel tem a permissão especificada."""
        return any(p.name == permission for p in self.permissions)
    
    def __repr__(self):
        return f'<Role {self.name}>'

class UserRole(db.Model):
    """Associação entre usuários e roles."""
    __tablename__ = 'user_role'
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
