"""
Módulo de modelos para Permissões.
"""
from datetime import datetime
from app.extensions import db

class Permission(db.Model):
    """Modelo de permissão do sistema."""
    __tablename__ = 'permissions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    description = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento com roles (muitos para muitos)
    roles = db.relationship('Role', secondary='role_permission', back_populates='permissions')
    
    def __repr__(self):
        return f'<Permission {self.name}>'

class RolePermission(db.Model):
    """Associação entre roles e permissões."""
    __tablename__ = 'role_permission'
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), primary_key=True)
    permission_id = db.Column(db.Integer, db.ForeignKey('permissions.id'), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

