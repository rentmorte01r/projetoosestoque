"""
Módulo para o modelo ActivityLog.
"""
from datetime import datetime
from app.extensions import db

class ActivityLog(db.Model):
    """Modelo para registro de atividades do sistema."""
    
    __tablename__ = 'activity_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento (opcional, se necessário)
    # user = db.relationship('User', backref='activity_logs')

    def __repr__(self):
        """Representação em string do objeto."""
        return f'<ActivityLog {self.id}: {self.action}>'
