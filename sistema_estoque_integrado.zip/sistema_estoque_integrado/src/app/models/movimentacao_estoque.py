"""
Módulo para o modelo MovimentacaoEstoque.
"""
from datetime import datetime
from app.extensions import db

class MovimentacaoEstoque(db.Model):
    """Modelo de movimentação de estoque."""
    __tablename__ = 'movimentacoes_estoque'
    
    id = db.Column(db.Integer, primary_key=True)
    produto_id = db.Column(db.Integer, db.ForeignKey('produtos.id'), nullable=False)
    tipo_movimentacao = db.Column(db.String(20), nullable=False, index=True)  # ENTRADA, SAIDA, AJUSTE
    quantidade = db.Column(db.Integer, nullable=False)
    data_movimentacao = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    ordem_servico_id = db.Column(db.Integer, db.ForeignKey('ordens_servico.id'))
    observacoes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    usuario = db.relationship('User', backref='movimentacoes_estoque')
    ordem_servico = db.relationship('OrdemServico', backref='movimentacoes_estoque')
    
    def __repr__(self):
        return f'<MovimentacaoEstoque {self.tipo_movimentacao} - {self.quantidade} - {self.produto.nome if self.produto else "N/A"}>'
    
    @property
    def quantidade_com_sinal(self):
        """Retorna a quantidade com sinal baseado no tipo de movimentação."""
        if self.tipo_movimentacao == 'ENTRADA':
            return self.quantidade
        elif self.tipo_movimentacao == 'SAIDA':
            return -self.quantidade
        else:  # AJUSTE
            return self.quantidade
    
    def to_dict(self):
        """Converte o objeto para dicionário para serialização JSON."""
        return {
            'id': self.id,
            'produto_id': self.produto_id,
            'produto_nome': self.produto.nome if self.produto else None,
            'produto_codigo': self.produto.codigo if self.produto else None,
            'tipo_movimentacao': self.tipo_movimentacao,
            'quantidade': self.quantidade,
            'quantidade_com_sinal': self.quantidade_com_sinal,
            'data_movimentacao': self.data_movimentacao.isoformat() if self.data_movimentacao else None,
            'usuario_id': self.usuario_id,
            'usuario_nome': self.usuario.name if self.usuario else None,
            'ordem_servico_id': self.ordem_servico_id,
            'ordem_servico_numero': self.ordem_servico.numero if self.ordem_servico else None,
            'observacoes': self.observacoes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @staticmethod
    def get_tipos_movimentacao():
        """Retorna os tipos de movimentação disponíveis."""
        return ['ENTRADA', 'SAIDA', 'AJUSTE']
    
    @classmethod
    def criar_movimentacao(cls, produto_id, tipo_movimentacao, quantidade, usuario_id, ordem_servico_id=None, observacoes=None):
        """
        Cria uma nova movimentação de estoque.
        
        Args:
            produto_id: ID do produto
            tipo_movimentacao: Tipo da movimentação (ENTRADA, SAIDA, AJUSTE)
            quantidade: Quantidade movimentada
            usuario_id: ID do usuário que realizou a movimentação
            ordem_servico_id: ID da ordem de serviço (opcional)
            observacoes: Observações sobre a movimentação (opcional)
        
        Returns:
            MovimentacaoEstoque: Instância da movimentação criada
        """
        movimentacao = cls(
            produto_id=produto_id,
            tipo_movimentacao=tipo_movimentacao,
            quantidade=quantidade,
            usuario_id=usuario_id,
            ordem_servico_id=ordem_servico_id,
            observacoes=observacoes
        )
        
        db.session.add(movimentacao)
        db.session.commit()
        
        return movimentacao

