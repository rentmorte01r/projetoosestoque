"""
Módulo para o modelo ItemOrdemServico.
Este modelo representa a associação entre produtos e ordens de serviço.
"""
from app.extensions import db
from datetime import datetime

class ItemOrdemServico(db.Model):
    """Modelo para itens utilizados em ordens de serviço."""
    
    __tablename__ = 'item_ordem_servico'
    
    id = db.Column(db.Integer, primary_key=True)
    ordem_servico_id = db.Column(db.Integer, db.ForeignKey("ordens_servico.id"), nullable=False)
    produto_id = db.Column(db.Integer, db.ForeignKey("produtos.id"), nullable=False)
    quantidade_utilizada = db.Column(db.Float, nullable=False)
    quantidade_prevista = db.Column(db.Float, nullable=True)
    preco_unitario = db.Column(db.Numeric(10, 2), nullable=True)
    observacoes = db.Column(db.Text)
    data_utilizacao = db.Column(db.DateTime, default=datetime.utcnow)
    usuario_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    
    # Status do item
    STATUS_PREVISTO = 'PREVISTO'
    STATUS_UTILIZADO = 'UTILIZADO'
    STATUS_DEVOLVIDO = 'DEVOLVIDO'
    
    status = db.Column(db.String(20), default=STATUS_PREVISTO, nullable=False)
    
    # Relacionamentos
    ordem_servico = db.relationship('OrdemServico', backref='itens_utilizados')
    produto = db.relationship('Produto', backref='utilizacoes_os')
    usuario = db.relationship('User', backref='itens_os_utilizados')
    
    def __repr__(self):
        return f'<ItemOrdemServico {self.produto.nome if self.produto else "N/A"} - OS {self.ordem_servico_id}>'
    
    def to_dict(self):
        """Converte o objeto para dicionário."""
        return {
            'id': self.id,
            'ordem_servico_id': self.ordem_servico_id,
            'produto_id': self.produto_id,
            'produto_nome': self.produto.nome if self.produto else None,
            'produto_codigo': self.produto.codigo if self.produto else None,
            'quantidade_utilizada': float(self.quantidade_utilizada),
            'quantidade_prevista': float(self.quantidade_prevista) if self.quantidade_prevista else None,
            'preco_unitario': float(self.preco_unitario) if self.preco_unitario else None,
            'valor_total': float(self.quantidade_utilizada * (self.preco_unitario or 0)),
            'observacoes': self.observacoes,
            'data_utilizacao': self.data_utilizacao.isoformat() if self.data_utilizacao else None,
            'status': self.status,
            'usuario_nome': self.usuario.name if self.usuario else None
        }
    
    @property
    def valor_total(self):
        """Calcula o valor total do item."""
        if self.preco_unitario:
            return self.quantidade_utilizada * self.preco_unitario
        return 0
    
    def pode_ser_devolvido(self):
        """Verifica se o item pode ser devolvido ao estoque."""
        return self.status == self.STATUS_UTILIZADO
    
    def devolver_ao_estoque(self, quantidade_devolvida=None, usuario_id=None, observacoes=None):
        """Devolve o item ao estoque."""
        if not self.pode_ser_devolvido():
            raise ValueError("Item não pode ser devolvido")
        
        if quantidade_devolvida is None:
            quantidade_devolvida = self.quantidade_utilizada
        
        if quantidade_devolvida > self.quantidade_utilizada:
            raise ValueError("Quantidade a devolver não pode ser maior que a quantidade utilizada")
        
        # Criar movimentação de entrada no estoque
        from app.models import MovimentacaoEstoque
        
        movimentacao = MovimentacaoEstoque(
            produto_id=self.produto_id,
            tipo_movimentacao='ENTRADA',
            quantidade=quantidade_devolvida,
            estoque_anterior=self.produto.quantidade_atual,
            estoque_atual=self.produto.quantidade_atual + quantidade_devolvida,
            usuario_id=usuario_id or self.usuario_id,
            ordem_servico_id=self.ordem_servico_id,
            observacoes=observacoes or f"Devolução de item da OS {self.ordem_servico.numero if self.ordem_servico else self.ordem_servico_id}"
        )
        
        # Atualizar estoque do produto
        self.produto.quantidade_atual += quantidade_devolvida
        
        # Atualizar status do item
        if quantidade_devolvida == self.quantidade_utilizada:
            self.status = self.STATUS_DEVOLVIDO
        
        db.session.add(movimentacao)
        db.session.commit()
        
        return movimentacao

