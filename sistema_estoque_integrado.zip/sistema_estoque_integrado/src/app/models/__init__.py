"""
Inicialização dos modelos de dados.
Importa todos os modelos de seus respectivos arquivos para garantir modularidade.
"""
from .user import User, UserCondominio
from .condominio import Condominio, Administradora, Area
from .ordem import OrdemServico, OrdemStatusLog, OrdemComentario, OrdemArquivo
from .activity_log import ActivityLog
from .role import Role, UserRole
from .permission import Permission, RolePermission
from .fornecedor import Fornecedor
from .password_reset import PasswordReset
from .categoria_produto import CategoriaProduto
from .produto import Produto
from .movimentacao_estoque import MovimentacaoEstoque
from .item_ordem_servico import ItemOrdemServico

# Garantir que todas as classes de modelo necessárias estejam importadas aqui
# a partir de seus arquivos dedicados.

