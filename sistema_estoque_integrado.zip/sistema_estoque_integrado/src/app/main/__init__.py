"""
Rotas principais da aplicação.
Este módulo define as rotas principais da aplicação, como a página inicial.
"""
from flask import Blueprint, redirect, url_for

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Rota para a página inicial."""
    return redirect(url_for('auth.login'))

