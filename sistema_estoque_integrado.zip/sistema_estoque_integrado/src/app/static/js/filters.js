// Funcionalidades JavaScript para filtros de pesquisa

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar filtros
    initializeFilters();
    
    // Inicializar busca em tempo real
    initializeRealTimeSearch();
    
    // Inicializar contadores de filtros
    updateFilterCounts();
});

function initializeFilters() {
    // Adicionar eventos aos filtros
    const filterInputs = document.querySelectorAll('.filter-section input, .filter-section select');
    
    filterInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateFilterCounts();
            highlightActiveFilters();
        });
    });
    
    // Botão de limpar filtros
    const clearButtons = document.querySelectorAll('.btn-clear-filter, [onclick="clearFilters()"]');
    clearButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            clearAllFilters();
        });
    });
}

function initializeRealTimeSearch() {
    const searchInputs = document.querySelectorAll('#searchInput, input[placeholder*="Buscar"]');
    
    searchInputs.forEach(input => {
        let timeout;
        input.addEventListener('keyup', function() {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                if (typeof filterTable === 'function') {
                    filterTable();
                }
            }, 300);
        });
    });
}

function updateFilterCounts() {
    const filterSections = document.querySelectorAll('.filter-section');
    
    filterSections.forEach(section => {
        const inputs = section.querySelectorAll('input, select');
        let activeCount = 0;
        
        inputs.forEach(input => {
            if (input.type === 'text' || input.type === 'date') {
                if (input.value.trim() !== '') activeCount++;
            } else if (input.type === 'select-one') {
                if (input.value !== '' && input.value !== 'Todos' && input.value !== 'Todas') {
                    activeCount++;
                }
            }
        });
        
        // Atualizar indicador visual
        let countBadge = section.querySelector('.filter-count');
        if (activeCount > 0) {
            if (!countBadge) {
                countBadge = document.createElement('span');
                countBadge.className = 'filter-count';
                const header = section.querySelector('.card-header h5, h5');
                if (header) header.appendChild(countBadge);
            }
            countBadge.textContent = activeCount;
            section.classList.add('filter-active');
        } else {
            if (countBadge) countBadge.remove();
            section.classList.remove('filter-active');
        }
    });
}

function highlightActiveFilters() {
    const filterInputs = document.querySelectorAll('.filter-section input, .filter-section select');
    
    filterInputs.forEach(input => {
        const hasValue = input.value && input.value !== '' && input.value !== 'Todos' && input.value !== 'Todas';
        
        if (hasValue) {
            input.classList.add('border-primary');
            input.style.backgroundColor = 'rgba(13, 110, 253, 0.05)';
        } else {
            input.classList.remove('border-primary');
            input.style.backgroundColor = '';
        }
    });
}

function clearAllFilters() {
    const filterInputs = document.querySelectorAll('.filter-section input, .filter-section select');
    
    filterInputs.forEach(input => {
        if (input.type === 'text' || input.type === 'date') {
            input.value = '';
        } else if (input.type === 'select-one') {
            input.selectedIndex = 0;
        }
        
        input.classList.remove('border-primary');
        input.style.backgroundColor = '';
    });
    
    // Atualizar contadores
    updateFilterCounts();
    
    // Aplicar filtros (limpar tabela)
    if (typeof filterTable === 'function') {
        filterTable();
    }
    
    // Remover parâmetros da URL
    const url = new URL(window.location);
    url.search = '';
    window.history.replaceState({}, '', url);
}

// Função melhorada para filtrar tabelas
function filterTable() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
    const adminFilter = document.getElementById('adminFilter')?.value.toLowerCase() || '';
    const categoriaFilter = document.getElementById('categoriaFilter')?.value.toLowerCase() || '';
    const condominioFilter = document.getElementById('condominioFilter')?.value.toLowerCase() || '';
    const administradoraFilter = document.getElementById('administradoraFilter')?.value.toLowerCase() || '';
    const cityFilter = document.getElementById('cityFilter')?.value.toLowerCase() || '';
    const actionFilter = document.getElementById('actionFilter')?.value.toLowerCase() || '';
    const dateFilter = document.getElementById('dateFilter')?.value || '';
    
    const tables = document.querySelectorAll('table[id$="Table"]');
    
    tables.forEach(table => {
        const rows = table.getElementsByTagName('tr');
        let visibleRows = 0;
        
        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const cells = row.cells;
            let showRow = true;
            
            // Busca geral
            if (searchTerm) {
                const rowText = row.textContent.toLowerCase();
                if (!rowText.includes(searchTerm)) {
                    showRow = false;
                }
            }
            
            // Filtros específicos baseados no tipo de tabela
            if (showRow && statusFilter) {
                const statusCell = findCellByContent(cells, ['status', 'ativo', 'inativo', 'pendente']);
                if (statusCell && !statusCell.textContent.toLowerCase().includes(statusFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && adminFilter) {
                const typeCell = findCellByContent(cells, ['admin', 'usuário', 'tipo']);
                if (typeCell && !typeCell.textContent.toLowerCase().includes(adminFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && categoriaFilter) {
                const categoriaCell = findCellByContent(cells, ['categoria']);
                if (categoriaCell && !categoriaCell.textContent.toLowerCase().includes(categoriaFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && condominioFilter) {
                const condominioCell = findCellByContent(cells, ['condomínio']);
                if (condominioCell && !condominioCell.textContent.toLowerCase().includes(condominioFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && administradoraFilter) {
                const administradoraCell = findCellByContent(cells, ['administradora']);
                if (administradoraCell && !administradoraCell.textContent.toLowerCase().includes(administradoraFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && cityFilter) {
                const cityCell = findCellByContent(cells, ['cidade']);
                if (cityCell && !cityCell.textContent.toLowerCase().includes(cityFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && actionFilter) {
                const actionCell = findCellByContent(cells, ['ação']);
                if (actionCell && !actionCell.textContent.toLowerCase().includes(actionFilter)) {
                    showRow = false;
                }
            }
            
            if (showRow && dateFilter) {
                const dateCell = findCellByContent(cells, ['data']);
                if (dateCell) {
                    const cellDate = dateCell.textContent.split(' ')[0];
                    const filterDate = new Date(dateFilter).toLocaleDateString('pt-BR');
                    if (cellDate !== filterDate) {
                        showRow = false;
                    }
                }
            }
            
            row.style.display = showRow ? '' : 'none';
            if (showRow) visibleRows++;
        }
        
        // Mostrar mensagem se não houver resultados
        updateNoResultsMessage(table, visibleRows);
    });
}

function findCellByContent(cells, keywords) {
    for (let cell of cells) {
        const cellText = cell.textContent.toLowerCase();
        for (let keyword of keywords) {
            if (cellText.includes(keyword)) {
                return cell;
            }
        }
    }
    return null;
}

function updateNoResultsMessage(table, visibleRows) {
    const tbody = table.querySelector('tbody');
    let noResultsRow = table.querySelector('.no-results-row');
    
    if (visibleRows === 0) {
        if (!noResultsRow) {
            noResultsRow = document.createElement('tr');
            noResultsRow.className = 'no-results-row';
            noResultsRow.innerHTML = `
                <td colspan="100%" class="text-center py-4">
                    <i class="fas fa-search fa-2x text-muted mb-2"></i>
                    <p class="text-muted mb-0">Nenhum resultado encontrado para os filtros aplicados.</p>
                </td>
            `;
            tbody.appendChild(noResultsRow);
        }
    } else {
        if (noResultsRow) {
            noResultsRow.remove();
        }
    }
}

// Função para salvar estado dos filtros
function saveFilterState() {
    const filterInputs = document.querySelectorAll('.filter-section input, .filter-section select');
    const filterState = {};
    
    filterInputs.forEach(input => {
        if (input.id) {
            filterState[input.id] = input.value;
        }
    });
    
    localStorage.setItem('filterState', JSON.stringify(filterState));
}

// Função para restaurar estado dos filtros
function restoreFilterState() {
    const savedState = localStorage.getItem('filterState');
    if (savedState) {
        const filterState = JSON.parse(savedState);
        
        Object.keys(filterState).forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.value = filterState[inputId];
            }
        });
        
        updateFilterCounts();
        highlightActiveFilters();
    }
}

// Auto-salvar estado dos filtros
document.addEventListener('change', function(e) {
    if (e.target.closest('.filter-section')) {
        saveFilterState();
    }
});

// Restaurar estado ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    restoreFilterState();
});

