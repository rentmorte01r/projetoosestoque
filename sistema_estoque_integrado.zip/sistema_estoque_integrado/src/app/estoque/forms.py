"""
Formulários para o módulo de estoque.
"""
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, FloatField, BooleanField, SubmitField, DateField, DecimalField
from wtforms.validators import DataRequired, Length, NumberRange, Optional, ValidationError
from app.models import CategoriaProduto, Fornecedor, Produto

class CategoriaProdutoForm(FlaskForm):
    """Formulário para cadastro/edição de categoria de produto."""
    nome = StringField('Nome', validators=[DataRequired(), Length(min=2, max=100)])
    descricao = TextAreaField('Descrição', validators=[Optional(), Length(max=500)])
    ativo = BooleanField('Ativo', default=True)
    submit = SubmitField('Salvar')
    
    def __init__(self, categoria=None, *args, **kwargs):
        super(CategoriaProdutoForm, self).__init__(*args, **kwargs)
        self.categoria = categoria
    
    def validate_nome(self, nome):
        """Valida se o nome da categoria já existe."""
        categoria = CategoriaProduto.query.filter_by(nome=nome.data).first()
        if categoria and (not self.categoria or categoria.id != self.categoria.id):
            raise ValidationError('Já existe uma categoria com este nome.')

class ProdutoForm(FlaskForm):
    """Formulário para cadastro/edição de produto."""
    nome = StringField('Nome', validators=[DataRequired(), Length(min=2, max=255)])
    codigo = StringField('Código', validators=[DataRequired(), Length(min=1, max=50)])
    descricao = TextAreaField('Descrição', validators=[Optional(), Length(max=1000)])
    unidade_medida = SelectField('Unidade de Medida', 
                                choices=[('UN', 'Unidade'), ('M', 'Metro'), ('KG', 'Quilograma'), 
                                        ('L', 'Litro'), ('M2', 'Metro Quadrado'), ('M3', 'Metro Cúbico'),
                                        ('CX', 'Caixa'), ('PC', 'Peça'), ('KIT', 'Kit')],
                                validators=[DataRequired()])
    quantidade_atual = IntegerField('Quantidade Atual', validators=[NumberRange(min=0)], default=0)
    preco_custo = DecimalField('Preço de Custo', validators=[Optional(), NumberRange(min=0)], places=2)
    local_armazenamento = StringField('Local de Armazenamento', validators=[Optional(), Length(max=100)])
    categoria_id = SelectField('Categoria', coerce=int, validators=[Optional()])
    fornecedor_id = SelectField('Fornecedor', coerce=int, validators=[Optional()])
    estoque_minimo = IntegerField('Estoque Mínimo', validators=[NumberRange(min=0)], default=0)
    estoque_maximo = IntegerField('Estoque Máximo', validators=[NumberRange(min=0)], default=0)
    data_vencimento = DateField('Data de Vencimento', validators=[Optional()])
    ativo = BooleanField('Ativo', default=True)
    submit = SubmitField('Salvar')
    
    def __init__(self, produto=None, *args, **kwargs):
        super(ProdutoForm, self).__init__(*args, **kwargs)
        self.produto = produto
        
        # Carregar opções de categoria
        self.categoria_id.choices = [(0, 'Selecione uma categoria')] + [
            (c.id, c.nome) for c in CategoriaProduto.query.filter_by(ativo=True).order_by(CategoriaProduto.nome).all()
        ]
        
        # Carregar opções de fornecedor (apenas fornecedores de produtos)
        self.fornecedor_id.choices = [(0, 'Selecione um fornecedor')] + [
            (f.id, f.nome) for f in Fornecedor.query.filter(
                Fornecedor.ativo == True,
                Fornecedor.tipo_fornecedor.in_(['Produto', 'Ambos'])
            ).order_by(Fornecedor.nome).all()
        ]
    
    def validate_codigo(self, codigo):
        """Valida se o código do produto já existe."""
        produto = Produto.query.filter_by(codigo=codigo.data).first()
        if produto and (not self.produto or produto.id != self.produto.id):
            raise ValidationError('Já existe um produto com este código.')
    
    def validate_estoque_maximo(self, estoque_maximo):
        """Valida se o estoque máximo é maior que o mínimo."""
        if estoque_maximo.data and self.estoque_minimo.data:
            if estoque_maximo.data <= self.estoque_minimo.data:
                raise ValidationError('O estoque máximo deve ser maior que o estoque mínimo.')

class MovimentacaoEstoqueForm(FlaskForm):
    """Formulário para registro de movimentação de estoque."""
    produto_id = SelectField('Produto', coerce=int, validators=[DataRequired()])
    tipo_movimentacao = SelectField('Tipo de Movimentação', 
                                   choices=[('ENTRADA', 'Entrada'), ('SAIDA', 'Saída'), ('AJUSTE', 'Ajuste')],
                                   validators=[DataRequired()])
    quantidade = IntegerField('Quantidade', validators=[DataRequired(), NumberRange(min=1)])
    ordem_servico_id = SelectField('Ordem de Serviço', coerce=int, validators=[Optional()])
    observacoes = TextAreaField('Observações', validators=[Optional(), Length(max=500)])
    submit = SubmitField('Registrar Movimentação')
    
    def __init__(self, *args, **kwargs):
        super(MovimentacaoEstoqueForm, self).__init__(*args, **kwargs)
        
        # Carregar opções de produto
        self.produto_id.choices = [(0, 'Selecione um produto')] + [
            (p.id, f'{p.codigo} - {p.nome}') for p in Produto.query.filter_by(ativo=True).order_by(Produto.nome).all()
        ]
        
        # Carregar opções de ordem de serviço (apenas abertas)
        from app.models import OrdemServico
        self.ordem_servico_id.choices = [(0, 'Nenhuma')] + [
            (os.id, f'{os.numero} - {os.titulo}') for os in OrdemServico.query.filter(
                OrdemServico.status.in_(['Aberta', 'Em Andamento'])
            ).order_by(OrdemServico.numero).all()
        ]

class FiltroEstoqueForm(FlaskForm):
    """Formulário para filtros de busca no estoque."""
    busca = StringField('Buscar por nome ou código')
    categoria_id = SelectField('Categoria', coerce=int, validators=[Optional()])
    fornecedor_id = SelectField('Fornecedor', coerce=int, validators=[Optional()])
    status_estoque = SelectField('Status do Estoque', 
                                choices=[('', 'Todos'), ('BAIXO', 'Estoque Baixo'), 
                                        ('NORMAL', 'Estoque Normal'), ('ALTO', 'Estoque Alto')],
                                validators=[Optional()])
    vencimento_proximo = BooleanField('Apenas itens próximos ao vencimento')
    submit = SubmitField('Filtrar')
    
    def __init__(self, *args, **kwargs):
        super(FiltroEstoqueForm, self).__init__(*args, **kwargs)
        
        # Carregar opções de categoria
        self.categoria_id.choices = [(0, 'Todas as categorias')] + [
            (c.id, c.nome) for c in CategoriaProduto.query.filter_by(ativo=True).order_by(CategoriaProduto.nome).all()
        ]
        
        # Carregar opções de fornecedor
        self.fornecedor_id.choices = [(0, 'Todos os fornecedores')] + [
            (f.id, f.nome) for f in Fornecedor.query.filter(
                Fornecedor.ativo == True,
                Fornecedor.tipo_fornecedor.in_(['Produto', 'Ambos'])
            ).order_by(Fornecedor.nome).all()
        ]



class FiltroMovimentacaoForm(FlaskForm):
    """Formulário para filtrar movimentações."""
    produto_id = SelectField('Produto', choices=[], coerce=int)
    tipo_movimentacao = SelectField('Tipo de Movimentação', choices=[
        ('', 'Todos'),
        ('ENTRADA', 'Entrada'),
        ('SAIDA', 'Saída'),
        ('AJUSTE', 'Ajuste')
    ])
    data_inicio = DateField('Data Início')
    data_fim = DateField('Data Fim')
    usuario_id = SelectField('Usuário', choices=[], coerce=int)
    submit = SubmitField('Filtrar')

class RelatorioForm(FlaskForm):
    """Formulário para gerar relatórios."""
    tipo_relatorio = SelectField('Tipo de Relatório', choices=[
        ('geral', 'Relatório Geral'),
        ('movimentacoes', 'Movimentações'),
        ('baixo_estoque', 'Produtos com Estoque Baixo'),
        ('por_categoria', 'Por Categoria')
    ], validators=[DataRequired()])
    
    formato = SelectField('Formato', choices=[
        ('pdf', 'PDF'),
        ('excel', 'Excel'),
        ('csv', 'CSV')
    ], validators=[DataRequired()])
    
    data_inicio = DateField('Data Início')
    data_fim = DateField('Data Fim')
    categoria_id = SelectField('Categoria (opcional)', choices=[], coerce=int)
    
    submit = SubmitField('Gerar Relatório')


class ItemOrdemServicoForm(FlaskForm):
    """Formulário para adicionar item a uma ordem de serviço."""
    produto_id = SelectField('Produto', coerce=int, validators=[DataRequired()])
    quantidade_utilizada = FloatField('Quantidade Utilizada', validators=[DataRequired(), NumberRange(min=0.01)])
    quantidade_prevista = FloatField('Quantidade Prevista', validators=[Optional(), NumberRange(min=0)])
    preco_unitario = DecimalField('Preço Unitário', validators=[Optional(), NumberRange(min=0)], places=2)
    observacoes = TextAreaField('Observações', validators=[Optional(), Length(max=500)])
    submit = SubmitField('Adicionar Item')
    
    def validate_quantidade_utilizada(self, field):
        """Valida se há estoque suficiente."""
        if self.produto_id.data:
            produto = Produto.query.get(self.produto_id.data)
            if produto and field.data > produto.quantidade_atual:
                raise ValidationError(f'Estoque insuficiente. Disponível: {produto.quantidade_atual} {produto.unidade_medida}')

class FiltroConsumoOSForm(FlaskForm):
    """Formulário para filtrar relatório de consumo por OS."""
    data_inicio = DateField('Data Início', validators=[Optional()])
    data_fim = DateField('Data Fim', validators=[Optional()])
    status_os = SelectField('Status da OS', choices=[
        ('', 'Todos'),
        ('ABERTA', 'Aberta'),
        ('EM_ANDAMENTO', 'Em Andamento'),
        ('FINALIZADA', 'Finalizada'),
        ('CANCELADA', 'Cancelada')
    ])
    submit = SubmitField('Filtrar')

