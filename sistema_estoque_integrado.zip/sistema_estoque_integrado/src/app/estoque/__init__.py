from flask import Blueprint

estoque_bp = Blueprint("estoque", __name__, url_prefix="/estoque")

from app.estoque import routes


