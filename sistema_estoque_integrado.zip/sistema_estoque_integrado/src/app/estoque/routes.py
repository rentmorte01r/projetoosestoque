"""
Rotas para o módulo de estoque.
"""
from flask import render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_required, current_user
from sqlalchemy import or_, and_
from datetime import datetime, timedelta
from app.estoque import estoque_bp
from app.models import Produto, CategoriaProduto, MovimentacaoEstoque, Fornecedor
from app.extensions import db
from app.estoque.forms import ProdutoForm, CategoriaProdutoForm, MovimentacaoEstoqueForm, FiltroEstoqueForm
from app.utils.decorators import admin_required

@bp.route('/')
@login_required
def index():
    """Página principal do estoque."""
    # Estatísticas básicas
    total_produtos = Produto.query.filter_by(ativo=True).count()
    produtos_baixo_estoque = Produto.query.filter(
        Produto.ativo == True,
        Produto.estoque_minimo > 0,
        Produto.quantidade_atual <= Produto.estoque_minimo
    ).count()
    
    # Produtos próximos ao vencimento (30 dias)
    data_limite = datetime.utcnow() + timedelta(days=30)
    produtos_vencimento = Produto.query.filter(
        Produto.ativo == True,
        Produto.data_vencimento.isnot(None),
        Produto.data_vencimento <= data_limite
    ).count()
    
    # Últimas movimentações
    ultimas_movimentacoes = MovimentacaoEstoque.query.order_by(
        MovimentacaoEstoque.data_movimentacao.desc()
    ).limit(10).all()
    
    return render_template('estoque/index.html',
                         total_produtos=total_produtos,
                         produtos_baixo_estoque=produtos_baixo_estoque,
                         produtos_vencimento=produtos_vencimento,
                         ultimas_movimentacoes=ultimas_movimentacoes)

@bp.route('/produtos')
@login_required
def listar_produtos():
    """Lista todos os produtos com filtros."""
    form = FiltroEstoqueForm()
    
    # Query base
    query = Produto.query.filter_by(ativo=True)
    
    # Aplicar filtros se o formulário foi submetido
    if form.validate_on_submit():
        if form.busca.data:
            busca = f"%{form.busca.data}%"
            query = query.filter(or_(
                Produto.nome.ilike(busca),
                Produto.codigo.ilike(busca)
            ))
        
        if form.categoria_id.data and form.categoria_id.data != 0:
            query = query.filter_by(categoria_id=form.categoria_id.data)
        
        if form.fornecedor_id.data and form.fornecedor_id.data != 0:
            query = query.filter_by(fornecedor_id=form.fornecedor_id.data)
        
        if form.status_estoque.data:
            if form.status_estoque.data == 'BAIXO':
                query = query.filter(
                    Produto.estoque_minimo > 0,
                    Produto.quantidade_atual <= Produto.estoque_minimo
                )
            elif form.status_estoque.data == 'ALTO':
                query = query.filter(
                    Produto.estoque_maximo > 0,
                    Produto.quantidade_atual >= Produto.estoque_maximo
                )
        
        if form.vencimento_proximo.data:
            data_limite = datetime.utcnow() + timedelta(days=30)
            query = query.filter(
                Produto.data_vencimento.isnot(None),
                Produto.data_vencimento <= data_limite
            )
    
    # Paginação
    page = request.args.get('page', 1, type=int)
    produtos = query.order_by(Produto.nome).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('estoque/produtos.html', produtos=produtos, form=form)

@bp.route('/produtos/novo', methods=['GET', 'POST'])
@login_required
@admin_required
def novo_produto():
    """Cadastra um novo produto."""
    form = ProdutoForm()
    
    if form.validate_on_submit():
        produto = Produto(
            nome=form.nome.data,
            codigo=form.codigo.data,
            descricao=form.descricao.data,
            unidade_medida=form.unidade_medida.data,
            quantidade_atual=form.quantidade_atual.data,
            preco_custo=form.preco_custo.data,
            local_armazenamento=form.local_armazenamento.data,
            categoria_id=form.categoria_id.data if form.categoria_id.data != 0 else None,
            fornecedor_id=form.fornecedor_id.data if form.fornecedor_id.data != 0 else None,
            estoque_minimo=form.estoque_minimo.data,
            estoque_maximo=form.estoque_maximo.data,
            data_vencimento=form.data_vencimento.data,
            ativo=form.ativo.data
        )
        
        db.session.add(produto)
        db.session.commit()
        
        # Registra movimentação inicial se quantidade > 0
        if produto.quantidade_atual > 0:
            MovimentacaoEstoque.criar_movimentacao(
                produto_id=produto.id,
                tipo_movimentacao='ENTRADA',
                quantidade=produto.quantidade_atual,
                usuario_id=current_user.id,
                observacoes='Estoque inicial'
            )
        
        flash('Produto cadastrado com sucesso!', 'success')
        return redirect(url_for('estoque.listar_produtos'))
    
    return render_template('estoque/produto_form.html', form=form, titulo='Novo Produto')

@bp.route('/produtos/<int:id>/editar', methods=['GET', 'POST'])
@login_required
@admin_required
def editar_produto(id):
    """Edita um produto existente."""
    produto = Produto.query.get_or_404(id)
    form = ProdutoForm(produto=produto, obj=produto)
    
    if form.validate_on_submit():
        quantidade_anterior = produto.quantidade_atual
        
        form.populate_obj(produto)
        produto.categoria_id = form.categoria_id.data if form.categoria_id.data != 0 else None
        produto.fornecedor_id = form.fornecedor_id.data if form.fornecedor_id.data != 0 else None
        
        # Se a quantidade foi alterada, registra como ajuste
        if quantidade_anterior != produto.quantidade_atual:
            diferenca = produto.quantidade_atual - quantidade_anterior
            MovimentacaoEstoque.criar_movimentacao(
                produto_id=produto.id,
                tipo_movimentacao='AJUSTE',
                quantidade=abs(diferenca),
                usuario_id=current_user.id,
                observacoes=f'Ajuste manual: {quantidade_anterior} → {produto.quantidade_atual}'
            )
        
        db.session.commit()
        flash('Produto atualizado com sucesso!', 'success')
        return redirect(url_for('estoque.listar_produtos'))
    
    return render_template('estoque/produto_form.html', form=form, produto=produto, titulo='Editar Produto')

@bp.route('/produtos/<int:id>')
@login_required
def detalhe_produto(id):
    """Exibe detalhes de um produto."""
    produto = Produto.query.get_or_404(id)
    
    # Últimas movimentações do produto
    movimentacoes = MovimentacaoEstoque.query.filter_by(produto_id=id).order_by(
        MovimentacaoEstoque.data_movimentacao.desc()
    ).limit(20).all()
    
    return render_template('estoque/produto_detalhe.html', produto=produto, movimentacoes=movimentacoes)

@bp.route('/categorias')
@login_required
def listar_categorias():
    """Lista todas as categorias."""
    categorias = CategoriaProduto.query.filter_by(ativo=True).order_by(CategoriaProduto.nome).all()
    return render_template('estoque/categorias.html', categorias=categorias)

@bp.route('/categorias/nova', methods=['GET', 'POST'])
@login_required
@admin_required
def nova_categoria():
    """Cadastra uma nova categoria."""
    form = CategoriaProdutoForm()
    
    if form.validate_on_submit():
        categoria = CategoriaProduto(
            nome=form.nome.data,
            descricao=form.descricao.data,
            ativo=form.ativo.data
        )
        
        db.session.add(categoria)
        db.session.commit()
        
        flash('Categoria cadastrada com sucesso!', 'success')
        return redirect(url_for('estoque.listar_categorias'))
    
    return render_template('estoque/categoria_form.html', form=form, titulo='Nova Categoria')

@bp.route('/categorias/<int:id>/editar', methods=['GET', 'POST'])
@login_required
@admin_required
def editar_categoria(id):
    """Edita uma categoria existente."""
    categoria = CategoriaProduto.query.get_or_404(id)
    form = CategoriaProdutoForm(categoria=categoria, obj=categoria)
    
    if form.validate_on_submit():
        form.populate_obj(categoria)
        db.session.commit()
        
        flash('Categoria atualizada com sucesso!', 'success')
        return redirect(url_for('estoque.listar_categorias'))
    
    return render_template('estoque/categoria_form.html', form=form, categoria=categoria, titulo='Editar Categoria')

@bp.route('/movimentacoes/nova', methods=['GET', 'POST'])
@login_required
def nova_movimentacao():
    """Registra uma nova movimentação de estoque."""
    form = MovimentacaoEstoqueForm()
    
    if form.validate_on_submit():
        produto = Produto.query.get(form.produto_id.data)
        
        if not produto:
            flash('Produto não encontrado!', 'error')
            return redirect(url_for('estoque.nova_movimentacao'))
        
        # Calcula a quantidade com sinal baseado no tipo
        if form.tipo_movimentacao.data == 'ENTRADA':
            quantidade_delta = form.quantidade.data
        elif form.tipo_movimentacao.data == 'SAIDA':
            quantidade_delta = -form.quantidade.data
            # Verifica se há estoque suficiente
            if produto.quantidade_atual < form.quantidade.data:
                flash(f'Estoque insuficiente! Disponível: {produto.quantidade_atual}', 'error')
                return render_template('estoque/movimentacao_form.html', form=form, titulo='Nova Movimentação')
        else:  # AJUSTE
            quantidade_delta = form.quantidade.data - produto.quantidade_atual
        
        # Atualiza o produto
        produto.atualizar_quantidade(
            quantidade_delta=quantidade_delta,
            tipo_movimentacao=form.tipo_movimentacao.data,
            usuario_id=current_user.id,
            ordem_servico_id=form.ordem_servico_id.data if form.ordem_servico_id.data != 0 else None,
            observacoes=form.observacoes.data
        )
        
        flash('Movimentação registrada com sucesso!', 'success')
        return redirect(url_for('estoque.listar_movimentacoes'))
    
    return render_template('estoque/movimentacao_form.html', form=form, titulo='Nova Movimentação')

# APIs para integração
@bp.route('/api/produtos')
@login_required
def api_produtos():
    """API para listar produtos."""
    produtos = Produto.query.filter_by(ativo=True).all()
    return jsonify([produto.to_dict() for produto in produtos])

@bp.route('/api/produtos/<int:id>')
@login_required
def api_produto(id):
    """API para obter um produto específico."""
    produto = Produto.query.get_or_404(id)
    return jsonify(produto.to_dict())

@bp.route('/api/produtos/<int:id>/movimentar', methods=['POST'])
@login_required
def api_movimentar_produto(id):
    """API para movimentar estoque de um produto."""
    produto = Produto.query.get_or_404(id)
    data = request.get_json()
    
    if not data or 'tipo_movimentacao' not in data or 'quantidade' not in data:
        return jsonify({'error': 'Dados inválidos'}), 400
    
    try:
        quantidade = int(data['quantidade'])
        tipo = data['tipo_movimentacao']
        
        if tipo not in ['ENTRADA', 'SAIDA', 'AJUSTE']:
            return jsonify({'error': 'Tipo de movimentação inválido'}), 400
        
        if tipo == 'SAIDA' and produto.quantidade_atual < quantidade:
            return jsonify({'error': 'Estoque insuficiente'}), 400
        
        # Calcula delta
        if tipo == 'ENTRADA':
            delta = quantidade
        elif tipo == 'SAIDA':
            delta = -quantidade
        else:  # AJUSTE
            delta = quantidade - produto.quantidade_atual
        
        produto.atualizar_quantidade(
            quantidade_delta=delta,
            tipo_movimentacao=tipo,
            usuario_id=current_user.id,
            ordem_servico_id=data.get('ordem_servico_id'),
            observacoes=data.get('observacoes')
        )
        
        return jsonify({
            'success': True,
            'produto': produto.to_dict()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/api/alertas')
@login_required
def api_alertas():
    """API para obter alertas de estoque."""
    # Produtos com estoque baixo
    produtos_baixo = Produto.query.filter(
        Produto.ativo == True,
        Produto.estoque_minimo > 0,
        Produto.quantidade_atual <= Produto.estoque_minimo
    ).all()
    
    # Produtos próximos ao vencimento
    data_limite = datetime.utcnow() + timedelta(days=30)
    produtos_vencimento = Produto.query.filter(
        Produto.ativo == True,
        Produto.data_vencimento.isnot(None),
        Produto.data_vencimento <= data_limite
    ).all()
    
    return jsonify({
        'estoque_baixo': [p.to_dict() for p in produtos_baixo],
        'vencimento_proximo': [p.to_dict() for p in produtos_vencimento]
    })



@bp.route('/dashboard')
@login_required
def dashboard():
    """Dashboard principal do estoque com estatísticas e gráficos."""
    try:
        # Estatísticas principais
        total_produtos = Produto.query.filter_by(ativo=True).count()
        produtos_baixo_estoque = Produto.query.filter(
            Produto.quantidade_atual <= Produto.estoque_minimo,
            Produto.ativo == True
        ).count()
        
        # Movimentações do mês atual
        inicio_mes = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        movimentacoes_mes = MovimentacaoEstoque.query.filter(
            MovimentacaoEstoque.data_movimentacao >= inicio_mes
        ).count()
        
        # Movimentações do mês anterior para comparação
        if inicio_mes.month == 1:
            inicio_mes_anterior = inicio_mes.replace(year=inicio_mes.year - 1, month=12)
        else:
            inicio_mes_anterior = inicio_mes.replace(month=inicio_mes.month - 1)
        
        fim_mes_anterior = inicio_mes - timedelta(days=1)
        movimentacoes_mes_anterior = MovimentacaoEstoque.query.filter(
            MovimentacaoEstoque.data_movimentacao >= inicio_mes_anterior,
            MovimentacaoEstoque.data_movimentacao <= fim_mes_anterior
        ).count()
        
        # Calcular variação percentual
        if movimentacoes_mes_anterior > 0:
            variacao_movimentacoes = ((movimentacoes_mes - movimentacoes_mes_anterior) / movimentacoes_mes_anterior) * 100
        else:
            variacao_movimentacoes = 0
        
        # Valor total em estoque
        valor_total_estoque = db.session.query(
            func.sum(Produto.quantidade_atual * Produto.preco_custo)
        ).filter(Produto.ativo == True, Produto.preco_custo.isnot(None)).scalar() or 0
        
        # Novos produtos do mês
        novos_produtos_mes = Produto.query.filter(
            Produto.data_criacao >= inicio_mes,
            Produto.ativo == True
        ).count()
        
        # Top produtos mais movimentados (últimos 30 dias)
        trinta_dias_atras = datetime.now() - timedelta(days=30)
        top_produtos = db.session.query(
            Produto,
            func.count(MovimentacaoEstoque.id).label('total_movimentacoes')
        ).join(MovimentacaoEstoque).filter(
            MovimentacaoEstoque.data_movimentacao >= trinta_dias_atras
        ).group_by(Produto.id).order_by(
            func.count(MovimentacaoEstoque.id).desc()
        ).limit(5).all()
        
        # Dados para gráfico de movimentações (últimos 30 dias)
        labels_movimentacoes = []
        dados_entradas = []
        dados_saidas = []
        
        for i in range(30):
            data = datetime.now() - timedelta(days=29-i)
            labels_movimentacoes.append(data.strftime('%d/%m'))
            
            entradas = MovimentacaoEstoque.query.filter(
                func.date(MovimentacaoEstoque.data_movimentacao) == data.date(),
                MovimentacaoEstoque.tipo_movimentacao == 'ENTRADA'
            ).count()
            
            saidas = MovimentacaoEstoque.query.filter(
                func.date(MovimentacaoEstoque.data_movimentacao) == data.date(),
                MovimentacaoEstoque.tipo_movimentacao == 'SAIDA'
            ).count()
            
            dados_entradas.append(entradas)
            dados_saidas.append(saidas)
        
        # Distribuição por categoria
        distribuicao_categorias = db.session.query(
            CategoriaProduto.nome,
            func.count(Produto.id).label('total')
        ).join(Produto).filter(Produto.ativo == True).group_by(
            CategoriaProduto.id
        ).all()
        
        labels_categorias = [cat.nome for cat, total in distribuicao_categorias]
        dados_categorias = [total for cat, total in distribuicao_categorias]
        
        # Alertas
        alertas = []
        
        # Produtos com estoque baixo
        produtos_baixo = Produto.query.filter(
            Produto.quantidade_atual <= Produto.estoque_minimo,
            Produto.ativo == True
        ).all()
        
        for produto in produtos_baixo:
            alertas.append({
                'tipo': 'warning',
                'titulo': f'Estoque baixo: {produto.nome}',
                'descricao': f'Quantidade atual: {produto.quantidade_atual} {produto.unidade_medida} (mínimo: {produto.estoque_minimo})',
                'data': datetime.now(),
                'produto_id': produto.id
            })
        
        # Produtos próximos ao vencimento (se aplicável)
        if hasattr(Produto, 'data_vencimento'):
            trinta_dias_futuro = datetime.now() + timedelta(days=30)
            produtos_vencimento = Produto.query.filter(
                Produto.data_vencimento <= trinta_dias_futuro,
                Produto.data_vencimento >= datetime.now(),
                Produto.ativo == True
            ).all()
            
            for produto in produtos_vencimento:
                dias_restantes = (produto.data_vencimento - datetime.now()).days
                alertas.append({
                    'tipo': 'danger' if dias_restantes <= 7 else 'warning',
                    'titulo': f'Produto próximo ao vencimento: {produto.nome}',
                    'descricao': f'Vence em {dias_restantes} dias ({produto.data_vencimento.strftime("%d/%m/%Y")})',
                    'data': datetime.now(),
                    'produto_id': produto.id
                })
        
        # Análise de tendências por categoria
        tendencias = []
        for categoria, total_atual in distribuicao_categorias:
            # Comparar com mês anterior
            total_anterior = db.session.query(func.count(Produto.id)).join(
                CategoriaProduto
            ).filter(
                CategoriaProduto.nome == categoria,
                Produto.data_criacao < inicio_mes,
                Produto.ativo == True
            ).scalar() or 0
            
            if total_anterior > 0:
                variacao = ((total_atual - total_anterior) / total_anterior) * 100
            else:
                variacao = 100 if total_atual > 0 else 0
            
            if variacao > 5:
                direcao = 'up'
            elif variacao < -5:
                direcao = 'down'
            else:
                direcao = 'neutral'
            
            tendencias.append({
                'categoria': categoria,
                'variacao': abs(variacao),
                'direcao': direcao
            })
        
        estatisticas = {
            'total_produtos': total_produtos,
            'produtos_baixo_estoque': produtos_baixo_estoque,
            'movimentacoes_mes': movimentacoes_mes,
            'variacao_movimentacoes': variacao_movimentacoes,
            'valor_total_estoque': valor_total_estoque,
            'novos_produtos_mes': novos_produtos_mes
        }
        
        return render_template('estoque/dashboard.html',
                             estatisticas=estatisticas,
                             top_produtos=top_produtos,
                             labels_movimentacoes=labels_movimentacoes,
                             dados_entradas=dados_entradas,
                             dados_saidas=dados_saidas,
                             labels_categorias=labels_categorias,
                             dados_categorias=dados_categorias,
                             alertas=alertas,
                             tendencias=tendencias)
    
    except Exception as e:
        flash(f'Erro ao carregar dashboard: {str(e)}', 'error')
        return redirect(url_for('estoque.index'))

@bp.route('/api/dashboard-dados')
@login_required
def api_dashboard_dados():
    """API para atualização automática dos dados do dashboard."""
    try:
        # Retornar dados atualizados em JSON para atualização via AJAX
        total_produtos = Produto.query.filter_by(ativo=True).count()
        produtos_baixo_estoque = Produto.query.filter(
            Produto.quantidade_atual <= Produto.estoque_minimo,
            Produto.ativo == True
        ).count()
        
        inicio_mes = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        movimentacoes_mes = MovimentacaoEstoque.query.filter(
            MovimentacaoEstoque.data_movimentacao >= inicio_mes
        ).count()
        
        return jsonify({
            'success': True,
            'data': {
                'total_produtos': total_produtos,
                'produtos_baixo_estoque': produtos_baixo_estoque,
                'movimentacoes_mes': movimentacoes_mes,
                'timestamp': datetime.now().isoformat()
            }
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/movimentacoes')
@login_required
def listar_movimentacoes():
    """Lista todas as movimentações com filtros."""
    from .forms import FiltroMovimentacaoForm
    
    form = FiltroMovimentacaoForm()
    
    # Configurar choices dos formulários
    form.produto_id.choices = [('', 'Todos os produtos')] + [
        (p.id, f"{p.codigo} - {p.nome}") for p in Produto.query.filter_by(ativo=True).all()
    ]
    
    form.usuario_id.choices = [('', 'Todos os usuários')] + [
        (u.id, u.name) for u in User.query.filter_by(is_active=True).all()
    ]
    
    # Query base
    query = MovimentacaoEstoque.query
    
    # Aplicar filtros
    if request.method == 'POST' and form.validate_on_submit():
        if form.produto_id.data:
            query = query.filter(MovimentacaoEstoque.produto_id == form.produto_id.data)
        
        if form.tipo_movimentacao.data:
            query = query.filter(MovimentacaoEstoque.tipo_movimentacao == form.tipo_movimentacao.data)
        
        if form.data_inicio.data:
            query = query.filter(MovimentacaoEstoque.data_movimentacao >= form.data_inicio.data)
        
        if form.data_fim.data:
            query = query.filter(MovimentacaoEstoque.data_movimentacao <= form.data_fim.data)
        
        if form.usuario_id.data:
            query = query.filter(MovimentacaoEstoque.usuario_id == form.usuario_id.data)
    
    # Ordenar por data mais recente
    query = query.order_by(MovimentacaoEstoque.data_movimentacao.desc())
    
    # Paginação
    page = request.args.get('page', 1, type=int)
    movimentacoes = query.paginate(
        page=page, per_page=20, error_out=False
    )
    
    # Calcular resumo
    resumo = {
        'total_entradas': query.filter(MovimentacaoEstoque.tipo_movimentacao == 'ENTRADA').count(),
        'total_saidas': query.filter(MovimentacaoEstoque.tipo_movimentacao == 'SAIDA').count(),
        'total_ajustes': query.filter(MovimentacaoEstoque.tipo_movimentacao == 'AJUSTE').count()
    }
    
    return render_template('estoque/movimentacoes.html',
                         form=form,
                         movimentacoes=movimentacoes,
                         resumo=resumo)

@bp.route('/relatorios/exportar')
@login_required
def exportar_relatorio():
    """Exporta relatório completo do estoque."""
    try:
        formato = request.args.get('formato', 'pdf')
        
        if formato == 'pdf':
            return gerar_relatorio_pdf()
        elif formato == 'excel':
            return gerar_relatorio_excel()
        else:
            flash('Formato de relatório não suportado', 'error')
            return redirect(url_for('estoque.dashboard'))
    
    except Exception as e:
        flash(f'Erro ao gerar relatório: {str(e)}', 'error')
        return redirect(url_for('estoque.dashboard'))

def gerar_relatorio_pdf():
    """Gera relatório em PDF."""
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    from io import BytesIO
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    
    # Título
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1  # Center
    )
    story.append(Paragraph("Relatório de Estoque", title_style))
    story.append(Spacer(1, 20))
    
    # Data do relatório
    story.append(Paragraph(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M')}", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Resumo geral
    story.append(Paragraph("Resumo Geral", styles['Heading2']))
    
    total_produtos = Produto.query.filter_by(ativo=True).count()
    produtos_baixo_estoque = Produto.query.filter(
        Produto.quantidade_atual <= Produto.estoque_minimo,
        Produto.ativo == True
    ).count()
    
    resumo_data = [
        ['Métrica', 'Valor'],
        ['Total de Produtos Ativos', str(total_produtos)],
        ['Produtos com Estoque Baixo', str(produtos_baixo_estoque)],
        ['Valor Total em Estoque', f"R$ {db.session.query(func.sum(Produto.quantidade_atual * Produto.preco_custo)).filter(Produto.ativo == True, Produto.preco_custo.isnot(None)).scalar() or 0:.2f}"]
    ]
    
    resumo_table = Table(resumo_data)
    resumo_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(resumo_table)
    story.append(Spacer(1, 30))
    
    # Lista de produtos
    story.append(Paragraph("Lista de Produtos", styles['Heading2']))
    
    produtos = Produto.query.filter_by(ativo=True).all()
    produtos_data = [['Código', 'Nome', 'Categoria', 'Estoque', 'Status']]
    
    for produto in produtos:
        status = 'Normal'
        if produto.quantidade_atual <= produto.estoque_minimo:
            status = 'Baixo'
        elif produto.quantidade_atual >= produto.estoque_maximo:
            status = 'Alto'
        
        produtos_data.append([
            produto.codigo,
            produto.nome[:30] + '...' if len(produto.nome) > 30 else produto.nome,
            produto.categoria.nome if produto.categoria else '-',
            f"{produto.quantidade_atual} {produto.unidade_medida}",
            status
        ])
    
    produtos_table = Table(produtos_data)
    produtos_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(produtos_table)
    
    doc.build(story)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'relatorio_estoque_{datetime.now().strftime("%Y%m%d_%H%M")}.pdf',
        mimetype='application/pdf'
    )

def gerar_relatorio_excel():
    """Gera relatório em Excel."""
    import pandas as pd
    from io import BytesIO
    
    buffer = BytesIO()
    
    # Dados dos produtos
    produtos = Produto.query.filter_by(ativo=True).all()
    produtos_data = []
    
    for produto in produtos:
        produtos_data.append({
            'Código': produto.codigo,
            'Nome': produto.nome,
            'Descrição': produto.descricao,
            'Categoria': produto.categoria.nome if produto.categoria else '',
            'Fornecedor': produto.fornecedor.nome if produto.fornecedor else '',
            'Unidade': produto.unidade_medida,
            'Estoque Atual': produto.quantidade_atual,
            'Estoque Mínimo': produto.estoque_minimo,
            'Estoque Máximo': produto.estoque_maximo,
            'Preço de Custo': produto.preco_custo,
            'Local': produto.local_armazenamento,
            'Status': 'Baixo' if produto.quantidade_atual <= produto.estoque_minimo else 'Normal'
        })
    
    df_produtos = pd.DataFrame(produtos_data)
    
    # Dados das movimentações (últimos 30 dias)
    trinta_dias_atras = datetime.now() - timedelta(days=30)
    movimentacoes = MovimentacaoEstoque.query.filter(
        MovimentacaoEstoque.data_movimentacao >= trinta_dias_atras
    ).all()
    
    movimentacoes_data = []
    for mov in movimentacoes:
        movimentacoes_data.append({
            'Data': mov.data_movimentacao.strftime('%d/%m/%Y %H:%M'),
            'Produto': mov.produto.nome,
            'Código': mov.produto.codigo,
            'Tipo': mov.tipo_movimentacao,
            'Quantidade': mov.quantidade,
            'Estoque Anterior': mov.estoque_anterior,
            'Estoque Atual': mov.estoque_atual,
            'Usuário': mov.usuario.name,
            'Observações': mov.observacoes or ''
        })
    
    df_movimentacoes = pd.DataFrame(movimentacoes_data)
    
    # Salvar no Excel
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        df_produtos.to_excel(writer, sheet_name='Produtos', index=False)
        df_movimentacoes.to_excel(writer, sheet_name='Movimentações', index=False)
    
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'relatorio_estoque_{datetime.now().strftime("%Y%m%d_%H%M")}.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@bp.route('/movimentacoes/exportar')
@login_required
def exportar_movimentacoes():
    """Exporta movimentações em CSV ou PDF."""
    formato = request.args.get('formato', 'csv')
    
    # Aplicar os mesmos filtros da listagem
    query = MovimentacaoEstoque.query
    
    if request.args.get('produto_id'):
        query = query.filter(MovimentacaoEstoque.produto_id == request.args.get('produto_id'))
    
    if request.args.get('tipo_movimentacao'):
        query = query.filter(MovimentacaoEstoque.tipo_movimentacao == request.args.get('tipo_movimentacao'))
    
    # Ordenar por data
    movimentacoes = query.order_by(MovimentacaoEstoque.data_movimentacao.desc()).all()
    
    if formato == 'csv':
        return gerar_csv_movimentacoes(movimentacoes)
    elif formato == 'pdf':
        return gerar_pdf_movimentacoes(movimentacoes)
    else:
        flash('Formato não suportado', 'error')
        return redirect(url_for('estoque.listar_movimentacoes'))

def gerar_csv_movimentacoes(movimentacoes):
    """Gera CSV das movimentações."""
    import csv
    from io import StringIO
    
    output = StringIO()
    writer = csv.writer(output)
    
    # Cabeçalho
    writer.writerow([
        'Data/Hora', 'Produto', 'Código', 'Tipo', 'Quantidade',
        'Estoque Anterior', 'Estoque Atual', 'Usuário', 'Observações'
    ])
    
    # Dados
    for mov in movimentacoes:
        writer.writerow([
            mov.data_movimentacao.strftime('%d/%m/%Y %H:%M:%S'),
            mov.produto.nome,
            mov.produto.codigo,
            mov.tipo_movimentacao,
            mov.quantidade,
            mov.estoque_anterior or '',
            mov.estoque_atual or '',
            mov.usuario.name,
            mov.observacoes or ''
        ])
    
    output.seek(0)
    
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={
            'Content-Disposition': f'attachment; filename=movimentacoes_{datetime.now().strftime("%Y%m%d_%H%M")}.csv'
        }
    )

def gerar_pdf_movimentacoes(movimentacoes):
    """Gera PDF das movimentações."""
    # Implementação similar ao relatório PDF principal
    # Por brevidade, retornando um placeholder
    flash('Funcionalidade em desenvolvimento', 'info')
    return redirect(url_for('estoque.listar_movimentacoes'))


# Rotas para integração com Ordens de Serviço

@bp.route('/os/<int:os_id>/itens')
@login_required
def listar_itens_os(os_id):
    """Lista itens utilizados em uma ordem de serviço."""
    from app.models import OrdemServico, ItemOrdemServico
    
    ordem = OrdemServico.query.get_or_404(os_id)
    itens = ItemOrdemServico.query.filter_by(ordem_servico_id=os_id).all()
    
    return render_template('estoque/itens_os.html', ordem=ordem, itens=itens)

@bp.route('/os/<int:os_id>/adicionar-item', methods=['GET', 'POST'])
@login_required
def adicionar_item_os(os_id):
    """Adiciona um item a uma ordem de serviço."""
    from app.models import OrdemServico, ItemOrdemServico
    from .forms import ItemOrdemServicoForm
    
    ordem = OrdemServico.query.get_or_404(os_id)
    form = ItemOrdemServicoForm()
    
    # Configurar choices do formulário
    form.produto_id.choices = [
        (p.id, f"{p.codigo} - {p.nome} (Estoque: {p.quantidade_atual} {p.unidade_medida})")
        for p in Produto.query.filter_by(ativo=True).order_by(Produto.nome).all()
    ]
    
    if form.validate_on_submit():
        try:
            produto = Produto.query.get(form.produto_id.data)
            
            # Verificar se há estoque suficiente
            if form.quantidade_utilizada.data > produto.quantidade_atual:
                flash(f'Estoque insuficiente. Disponível: {produto.quantidade_atual} {produto.unidade_medida}', 'error')
                return render_template('estoque/item_os_form.html', form=form, ordem=ordem)
            
            # Criar item da OS
            item = ItemOrdemServico(
                ordem_servico_id=os_id,
                produto_id=form.produto_id.data,
                quantidade_utilizada=form.quantidade_utilizada.data,
                quantidade_prevista=form.quantidade_prevista.data,
                preco_unitario=form.preco_unitario.data,
                observacoes=form.observacoes.data,
                usuario_id=current_user.id,
                status=ItemOrdemServico.STATUS_UTILIZADO
            )
            
            # Criar movimentação de saída no estoque
            movimentacao = MovimentacaoEstoque(
                produto_id=produto.id,
                tipo_movimentacao='SAIDA',
                quantidade=form.quantidade_utilizada.data,
                estoque_anterior=produto.quantidade_atual,
                estoque_atual=produto.quantidade_atual - form.quantidade_utilizada.data,
                usuario_id=current_user.id,
                ordem_servico_id=os_id,
                observacoes=f"Utilização na OS {ordem.numero} - {form.observacoes.data or ''}"
            )
            
            # Atualizar estoque do produto
            produto.quantidade_atual -= form.quantidade_utilizada.data
            
            db.session.add(item)
            db.session.add(movimentacao)
            db.session.commit()
            
            flash(f'Item {produto.nome} adicionado à OS com sucesso!', 'success')
            return redirect(url_for('estoque.listar_itens_os', os_id=os_id))
        
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao adicionar item: {str(e)}', 'error')
    
    return render_template('estoque/item_os_form.html', form=form, ordem=ordem)

@bp.route('/os/<int:os_id>/item/<int:item_id>/devolver', methods=['POST'])
@login_required
def devolver_item_os(os_id, item_id):
    """Devolve um item ao estoque."""
    from app.models import ItemOrdemServico
    
    item = ItemOrdemServico.query.filter_by(
        id=item_id, 
        ordem_servico_id=os_id
    ).first_or_404()
    
    try:
        quantidade_devolver = float(request.json.get('quantidade', item.quantidade_utilizada))
        observacoes = request.json.get('observacoes', '')
        
        movimentacao = item.devolver_ao_estoque(
            quantidade_devolvida=quantidade_devolver,
            usuario_id=current_user.id,
            observacoes=observacoes
        )
        
        return jsonify({
            'success': True,
            'message': f'Item devolvido ao estoque com sucesso!',
            'movimentacao_id': movimentacao.id
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@bp.route('/api/os/<int:os_id>/resumo-estoque')
@login_required
def api_resumo_estoque_os(os_id):
    """API para obter resumo do estoque utilizado em uma OS."""
    from app.models import ItemOrdemServico
    
    itens = ItemOrdemServico.query.filter_by(ordem_servico_id=os_id).all()
    
    resumo = {
        'total_itens': len(itens),
        'valor_total': sum(item.valor_total for item in itens),
        'itens_por_status': {},
        'produtos_utilizados': []
    }
    
    # Agrupar por status
    for item in itens:
        status = item.status
        if status not in resumo['itens_por_status']:
            resumo['itens_por_status'][status] = {
                'quantidade': 0,
                'valor': 0
            }
        resumo['itens_por_status'][status]['quantidade'] += 1
        resumo['itens_por_status'][status]['valor'] += item.valor_total
    
    # Lista de produtos utilizados
    for item in itens:
        resumo['produtos_utilizados'].append({
            'produto_nome': item.produto.nome,
            'produto_codigo': item.produto.codigo,
            'quantidade': item.quantidade_utilizada,
            'unidade': item.produto.unidade_medida,
            'valor_unitario': float(item.preco_unitario) if item.preco_unitario else 0,
            'valor_total': item.valor_total,
            'status': item.status
        })
    
    return jsonify(resumo)

@bp.route('/api/produtos/disponiveis')
@login_required
def api_produtos_disponiveis():
    """API para listar produtos disponíveis em estoque."""
    produtos = Produto.query.filter(
        Produto.ativo == True,
        Produto.quantidade_atual > 0
    ).order_by(Produto.nome).all()
    
    return jsonify([{
        'id': p.id,
        'codigo': p.codigo,
        'nome': p.nome,
        'quantidade_atual': p.quantidade_atual,
        'unidade_medida': p.unidade_medida,
        'preco_custo': float(p.preco_custo) if p.preco_custo else None,
        'categoria': p.categoria.nome if p.categoria else None,
        'local_armazenamento': p.local_armazenamento
    } for p in produtos])

@bp.route('/api/produto/<int:produto_id>/verificar-estoque')
@login_required
def api_verificar_estoque(produto_id):
    """API para verificar disponibilidade de estoque de um produto."""
    produto = Produto.query.get_or_404(produto_id)
    
    return jsonify({
        'produto_id': produto.id,
        'nome': produto.nome,
        'codigo': produto.codigo,
        'quantidade_atual': produto.quantidade_atual,
        'estoque_minimo': produto.estoque_minimo,
        'estoque_maximo': produto.estoque_maximo,
        'unidade_medida': produto.unidade_medida,
        'disponivel': produto.quantidade_atual > 0,
        'baixo_estoque': produto.quantidade_atual <= produto.estoque_minimo,
        'preco_custo': float(produto.preco_custo) if produto.preco_custo else None
    })

@bp.route('/relatorio/consumo-por-os')
@login_required
def relatorio_consumo_os():
    """Relatório de consumo de materiais por ordem de serviço."""
    from app.models import ItemOrdemServico, OrdemServico
    from sqlalchemy import func
    
    # Filtros
    data_inicio = request.args.get('data_inicio')
    data_fim = request.args.get('data_fim')
    status_os = request.args.get('status_os')
    
    # Query base
    query = db.session.query(
        OrdemServico.id,
        OrdemServico.numero,
        OrdemServico.titulo,
        OrdemServico.status,
        OrdemServico.data_criacao,
        func.count(ItemOrdemServico.id).label('total_itens'),
        func.sum(ItemOrdemServico.quantidade_utilizada * ItemOrdemServico.preco_unitario).label('valor_total')
    ).outerjoin(ItemOrdemServico).group_by(OrdemServico.id)
    
    # Aplicar filtros
    if data_inicio:
        query = query.filter(OrdemServico.data_criacao >= datetime.strptime(data_inicio, '%Y-%m-%d'))
    
    if data_fim:
        query = query.filter(OrdemServico.data_criacao <= datetime.strptime(data_fim, '%Y-%m-%d'))
    
    if status_os:
        query = query.filter(OrdemServico.status == status_os)
    
    ordens = query.order_by(OrdemServico.data_criacao.desc()).all()
    
    return render_template('estoque/relatorio_consumo_os.html', ordens=ordens)

@bp.route('/webhook/os-finalizada', methods=['POST'])
@login_required
def webhook_os_finalizada():
    """Webhook chamado quando uma OS é finalizada para processar devoluções automáticas."""
    try:
        data = request.get_json()
        os_id = data.get('ordem_servico_id')
        
        if not os_id:
            return jsonify({'error': 'ordem_servico_id é obrigatório'}), 400
        
        from app.models import ItemOrdemServico
        
        # Buscar itens não utilizados para devolução automática
        itens_nao_utilizados = ItemOrdemServico.query.filter_by(
            ordem_servico_id=os_id,
            status=ItemOrdemServico.STATUS_PREVISTO
        ).all()
        
        devolvidos = 0
        for item in itens_nao_utilizados:
            if item.quantidade_prevista and item.quantidade_prevista > item.quantidade_utilizada:
                quantidade_devolver = item.quantidade_prevista - item.quantidade_utilizada
                
                item.devolver_ao_estoque(
                    quantidade_devolvida=quantidade_devolver,
                    usuario_id=current_user.id,
                    observacoes=f"Devolução automática - OS finalizada"
                )
                devolvidos += 1
        
        return jsonify({
            'success': True,
            'message': f'{devolvidos} itens devolvidos automaticamente ao estoque'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

