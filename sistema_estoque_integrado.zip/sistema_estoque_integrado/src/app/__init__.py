from flask import Flask
from app.config import Config
from app.extensions import db, migrate, login_manager, csrf, mail, limiter, cache, compress, cors, bcrypt
from app.utils.performance import setup_performance_monitoring
from app.utils.notifications import setup_notification_system
from app.utils.backup import setup_backup_system

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    mail.init_app(app)
    limiter.init_app(app)
    cache.init_app(app)
    compress.init_app(app)
    cors.init_app(app)
    bcrypt.init_app(app)

    setup_performance_monitoring(app)
    setup_notification_system(app)
    setup_backup_system(app)

    
    @app.route('/')
    def index():
        return render_template('index.html')


    return app